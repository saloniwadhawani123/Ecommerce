# Kalakriti - Full Stack E-commerce Platform

Kalakriti is a production-style handcrafted e-commerce platform with B2C-first flow and optional vendor marketplace capability.

## Business Model
- Primary: B2C direct sales from platform inventory
- Secondary: Vendor/artisan onboarding with product listings
- Revenue model:
  - Direct platform product sales
  - Commission on vendor product sales
  - Featured listing priority/promotions
  - Coupons and seasonal campaigns

## Tech Stack
- Frontend: React + Vite + Tailwind CSS + Framer Motion
- Backend: Node.js + Express (MVC architecture)
- Database: MongoDB + Mongoose
- Auth: JWT + role-based access + OTP 2FA via email

## Security
- Strong password policy enforcement
- Password hashing with bcryptjs
- JWT auth in cookie and bearer mode
- CSRF token protection for non-GET requests
- Helmet, rate limiting, NoSQL sanitization, HPP hardening

## Core Modules
- Auth, profile, wishlist, loyalty, referrals
- Product catalog, search, filters, ratings/reviews
- Cart, checkout, order history, coupon redemption
- Vendor dashboard for products and earnings
- Admin dashboard for analytics, commissions, inventory alerts, support
- Legal pages and contact query storage
- Dark mode, toasts, loading skeletons, smooth page motion

## Setup
1. Backend
   - cd backend
   - copy .env.example .env
   - npm install
   - npm run seed
   - npm run dev

2. Frontend
   - cd frontend
   - copy .env.example .env
   - npm install
   - npm run dev

## Important Routes
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000/api/v1

## Seed Users
- Admin: admin@kalakriti.com / Admin@123
- Vendor: vendor@kalakriti.com / Vendor@123
- User: user@kalakriti.com / User@123

## Documentation
- API docs: backend/docs/API.md
- Schema docs: backend/docs/SCHEMA.md
- Backend setup: backend/README.md
