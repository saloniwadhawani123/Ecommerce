const mongoose = require("mongoose");
const connectDB = require("../src/config/db");
const User = require("../src/models/User");
const Product = require("../src/models/Product");
const Coupon = require("../src/models/Coupon");
const { generateReferralCode } = require("../src/utils/referral");

const run = async () => {
  await connectDB();

  await Promise.all([
    User.deleteMany({}),
    Product.deleteMany({}),
    Coupon.deleteMany({}),
  ]);

  const admin = await User.create({
    name: "Admin",
    email: "admin@kalakriti.com",
    password: "Admin@123",
    role: "admin",
    referralCode: generateReferralCode("admin"),
  });

  const vendor = await User.create({
    name: "Aarohi Artisan",
    email: "vendor@kalakriti.com",
    password: "Vendor@123",
    role: "vendor",
    referralCode: generateReferralCode("aarohi"),
    vendorProfile: {
      storeName: "Aarohi Handworks",
      bio: "Handmade decor and textile stories.",
      commissionRate: 12,
    },
  });

  const user = await User.create({
    name: "Priya Customer",
    email: "user@kalakriti.com",
    password: "User@123",
    role: "user",
    referralCode: generateReferralCode("priya"),
    referredBy: vendor._id,
  });

  const products = [
    {
      title: "Terracotta Temple Earrings",
      slug: "terracotta-temple-earrings",
      description: "Handpainted lightweight earrings inspired by folk motifs.",
      price: 899,
      discountPrice: 749,
      category: "Jewellery",
      images: ["/products/terracotta-temple-earrings.jpeg"],
      stock: 24,
      isPlatformProduct: false,
      vendor: vendor._id,
      isFeatured: true,
      priority: 9,
    },
    {
      title: "Madhubani Wall Frame",
      slug: "madhubani-wall-frame",
      description: "Statement wall frame for warm artistic interiors.",
      price: 2499,
      category: "Paintings",
      images: ["/products/madhubani-wall-frame.jpeg"],
      stock: 12,
      isPlatformProduct: true,
      isFeatured: true,
      priority: 8,
    },
    {
      title: "Handwoven Indigo Table Runner",
      slug: "handwoven-indigo-table-runner",
      description: "Natural-dye woven runner with tassel edging.",
      price: 1499,
      category: "Textiles",
      images: ["/products/handwoven-indigo-table-runner.jpeg"],
      stock: 5,
      isPlatformProduct: false,
      vendor: vendor._id,
    },
    {
      title: "Macrame Wall Hanging - Desert Bloom",
      slug: "macrame-wall-hanging-desert-bloom",
      description: "Hand-knotted cotton macrame with wooden dowel for boho interiors.",
      price: 1999,
      discountPrice: 1699,
      category: "Home Decor",
      images: ["/products/macrame-wall-hanging-desert-bloom.jpeg"],
      stock: 16,
      isPlatformProduct: true,
      isFeatured: true,
      priority: 7,
    },
    {
      title: "Blue Pottery Serving Bowl Set",
      slug: "blue-pottery-serving-bowl-set",
      description: "Set of 3 handpainted blue pottery bowls for festive table styling.",
      price: 2299,
      discountPrice: 1999,
      category: "Crafts",
      images: ["/products/blue-pottery-serving-bowl-set.jpeg"],
      stock: 20,
      isPlatformProduct: true,
    },
    {
      title: "Handloom Cotton Throw - Saffron",
      slug: "handloom-cotton-throw-saffron",
      description: "Soft handloom throw crafted by rural weaving clusters.",
      price: 1799,
      category: "Textiles",
      images: ["/products/handloom-cotton-throw-saffron.jpeg"],
      stock: 22,
      isPlatformProduct: false,
      vendor: vendor._id,
    },
    {
      title: "Personalized Name Plate - Floral Wood",
      slug: "personalized-name-plate-floral-wood",
      description: "Custom wooden name plate with floral hand-painted accents.",
      price: 1299,
      category: "Personalized Gifts",
      images: ["/products/personalized-name-plate-floral-wood.jpeg"],
      stock: 18,
      isPlatformProduct: false,
      vendor: vendor._id,
    },
    {
      title: "Brass Diya Set - Lotus Glow",
      slug: "brass-diya-set-lotus-glow",
      description: "Traditional brass diya set handcrafted for festive decor.",
      price: 1399,
      discountPrice: 1199,
      category: "Home Decor",
      images: ["/products/brass-diya-set-lotus-glow.jpeg"],
      stock: 30,
      isPlatformProduct: true,
    },
    {
      title: "Pichwai Cow Miniature Painting",
      slug: "pichwai-cow-miniature-painting",
      description: "Fine-detail Pichwai inspired miniature painting in natural pigments.",
      price: 2899,
      category: "Paintings",
      images: ["/products/pichwai-cow-miniature-painting.jpeg"],
      stock: 9,
      isPlatformProduct: false,
      vendor: vendor._id,
      isFeatured: true,
      priority: 8,
    },
    {
      title: "Tribal Silver Anklet Pair",
      slug: "tribal-silver-anklet-pair",
      description: "Oxidized handcrafted anklets inspired by tribal jewelry heritage.",
      price: 1599,
      category: "Jewellery",
      images: ["/products/tribal-silver-anklet-pair.jpeg"],
      stock: 14,
      isPlatformProduct: false,
      vendor: vendor._id,
    },
    {
      title: "Bamboo Pendant Lamp",
      slug: "bamboo-pendant-lamp",
      description: "Eco-friendly bamboo pendant lamp for warm ambient lighting.",
      price: 3199,
      discountPrice: 2799,
      category: "Home Decor",
      images: ["/products/bamboo-pendant-lamp.jpeg"],
      stock: 11,
      isPlatformProduct: true,
    },
    {
      title: "Kantha Embroidered Cushion Covers",
      slug: "kantha-embroidered-cushion-covers",
      description: "Set of vibrant Kantha stitch cushion covers made by artisans.",
      price: 999,
      category: "Textiles",
      images: ["/products/kantha-embroidered-cushion-covers.jpeg"],
      stock: 28,
      isPlatformProduct: false,
      vendor: vendor._id,
    },
    {
      title: "Miniature Clay Fridge Magnets - Folk Set",
      slug: "miniature-clay-fridge-magnets-folk-set",
      description: "Set of 6 hand-painted clay magnets featuring folk motifs.",
      price: 699,
      category: "Crafts",
      images: ["/products/miniature-clay-fridge-magnets-folk-set.jpeg"],
      stock: 35,
      isPlatformProduct: true,
    },
    {
      title: "Customized Handwritten Letter Frame",
      slug: "customized-handwritten-letter-frame",
      description: "Personalized keepsake frame with handwritten note print.",
      price: 1499,
      category: "Personalized Gifts",
      images: ["/products/customized-handwritten-letter-frame.jpeg"],
      stock: 17,
      isPlatformProduct: true,
    },
    {
      title: "Warli Art Coaster Set",
      slug: "warli-art-coaster-set",
      description: "MDF coaster set hand-painted with traditional Warli patterns.",
      price: 899,
      category: "Paintings",
      images: ["/products/warli-art-coaster-set.jpeg"],
      stock: 24,
      isPlatformProduct: false,
      vendor: vendor._id,
    },
  ];

  await Product.insertMany(products);

  await Coupon.create({
    code: "KALA10",
    description: "10% welcome discount",
    type: "percent",
    value: 10,
    minOrderValue: 999,
    usageLimit: 100,
    active: true,
  });

  console.log("Seed data inserted");
  console.log("Admin: admin@kalakriti.com / Admin@123");
  console.log("Vendor: vendor@kalakriti.com / Vendor@123");
  console.log("User: user@kalakriti.com / User@123");
  console.log("Sample user id:", user._id.toString());

  await mongoose.connection.close();
};

run().catch(async (error) => {
  console.error(error);
  await mongoose.connection.close();
  process.exit(1);
});
