module.exports = [
  "Jewellery",
  "Home Decor",
  "Paintings",
  "Crafts",
  "Textiles",
  "Personalized Gifts",
];
