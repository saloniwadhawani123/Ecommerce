const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const hpp = require("hpp");
const cookieParser = require("cookie-parser");
const env = require("../config/env");

const sanitizeObject = (value) => {
  if (!value || typeof value !== "object") return;

  Object.keys(value).forEach((key) => {
    if (key.startsWith("$") || key.includes(".")) {
      delete value[key];
      return;
    }

    sanitizeObject(value[key]);
  });
};

const nosqlSanitize = (req, _res, next) => {
  sanitizeObject(req.body);
  sanitizeObject(req.params);
  sanitizeObject(req.query);
  next();
};

const securityStack = (app) => {
  const allowedOrigins = [env.clientUrl, "http://localhost:5173", "http://127.0.0.1:5173"];

  app.use(
    cors({
      origin: (origin, callback) => {
        // Allow same-origin or non-browser requests (e.g., curl/Postman).
        if (!origin) return callback(null, true);

        const isExplicitlyAllowed = allowedOrigins.includes(origin);
        const isLocalhostDev =
          env.nodeEnv !== "production" && /^https?:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin);

        if (isExplicitlyAllowed || isLocalhostDev) {
          return callback(null, true);
        }

        return callback(new Error("CORS origin not allowed"));
      },
      credentials: true,
    })
  );
  app.use(helmet());
  app.use(cookieParser());
  app.use(nosqlSanitize);
  app.use(hpp());

  app.use(
    "/api",
    rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 300,
      standardHeaders: true,
      legacyHeaders: false,
      message: { message: "Too many requests, please try again later." },
    })
  );
};

module.exports = securityStack;
