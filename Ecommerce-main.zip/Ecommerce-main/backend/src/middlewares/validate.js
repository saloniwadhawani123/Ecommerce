const AppError = require("../utils/appError");

const validate = (schema) => (req, _res, next) => {
  const parsed = schema.safeParse({
    body: req.body,
    params: req.params,
    query: req.query,
  });

  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => i.message).join(", ");
    return next(new AppError(`Validation error: ${issues}`, 400));
  }

  req.validated = parsed.data;
  next();
};

module.exports = validate;
