const crypto = require("crypto");
const AppError = require("../utils/appError");

const ensureCsrfCookie = (req, res, next) => {
  const existing = req.cookies.csrfToken;
  if (!existing) {
    const token = crypto.randomBytes(24).toString("hex");
    res.cookie("csrfToken", token, {
      httpOnly: false,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    });
    req.csrfToken = token;
  } else {
    req.csrfToken = existing;
  }
  next();
};

const verifyCsrf = (req, _res, next) => {
  const method = req.method.toUpperCase();
  const safe = ["GET", "HEAD", "OPTIONS"].includes(method);
  if (safe) return next();

  const cookieToken = req.cookies.csrfToken;
  const headerToken = req.headers["x-csrf-token"];

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    return next(new AppError("Invalid CSRF token", 403));
  }

  next();
};

module.exports = { ensureCsrfCookie, verifyCsrf };
