const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const roles = require("../constants/roles");

const addressSchema = new mongoose.Schema(
  {
    line1: String,
    line2: String,
    city: String,
    state: String,
    postalCode: String,
    country: { type: String, default: "India" },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 8, select: false },
    role: {
      type: String,
      enum: [roles.ADMIN, roles.USER, roles.VENDOR],
      default: roles.USER,
    },
    phone: String,
    avatar: String,
    isEmailVerified: { type: Boolean, default: false },
    twoFactorEnabled: { type: Boolean, default: false },
    wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: "Product" }],
    cart: [
      {
        product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
        quantity: { type: Number, default: 1, min: 1 },
      },
    ],
    loyaltyPoints: { type: Number, default: 0 },
    dailyRewardStreak: { type: Number, default: 0 },
    lastDailyRewardAt: Date,
    referralCode: { type: String, unique: true, sparse: true },
    referredBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    referralRewards: { type: Number, default: 0 },
    addresses: [addressSchema],
    vendorProfile: {
      storeName: String,
      bio: String,
      commissionRate: { type: Number, default: 12 },
      earnings: { type: Number, default: 0 },
      totalSales: { type: Number, default: 0 },
    },
  },
  { timestamps: true }
);

userSchema.pre("save", async function () {
  if (!this.isModified("password")) return;

  this.password = await bcrypt.hash(this.password, 12);
});

userSchema.methods.comparePassword = async function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

module.exports = mongoose.model("User", userSchema);