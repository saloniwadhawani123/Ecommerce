const mongoose = require("mongoose");

const orderItemSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
    titleSnapshot: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    quantity: { type: Number, required: true, min: 1 },
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    commissionRate: { type: Number, default: 0 },
    commissionAmount: { type: Number, default: 0 },
    lineTotal: { type: Number, required: true },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    items: [orderItemSchema],
    shippingAddress: {
      line1: String,
      line2: String,
      city: String,
      state: String,
      postalCode: String,
      country: { type: String, default: "India" },
    },
    paymentMethod: { type: String, enum: ["mock", "razorpay", "cod", "upi", "card"], default: "mock" },
    paymentStatus: { type: String, enum: ["pending", "paid", "failed"], default: "pending" },
    paymentMeta: {
      upiId: String,
      cardLast4: String,
      provider: String,
    },
    orderStatus: {
      type: String,
      enum: ["placed", "processing", "shipped", "delivered", "cancelled"],
      default: "placed",
    },
    subtotal: { type: Number, required: true },
    discount: { type: Number, default: 0 },
    shippingFee: { type: Number, default: 0 },
    loyaltyRedeemed: { type: Number, default: 0 },
    couponCode: String,
    total: { type: Number, required: true },
    trackingType: { type: String, enum: ["platform", "vendor", "mixed"], default: "platform" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);
