const express = require("express");
const { protect, authorize } = require("../middlewares/auth");
const roles = require("../constants/roles");
const controller = require("../controllers/adminController");

const router = express.Router();

router.use(protect, authorize(roles.ADMIN));
router.get("/analytics", controller.getDashboardAnalytics);
router.get("/users", controller.listUsers);
router.get("/vendors", controller.listVendors);
router.get("/products", controller.listProducts);
router.get("/products/pending", controller.listPendingProducts);
router.get("/orders", controller.listOrders);
router.patch("/orders/:orderId/status", controller.updateOrderStatus);
router.patch("/products/:productId/priority", controller.setProductPriority);
router.patch("/products/:productId/review", controller.reviewProductApproval);
router.patch("/vendors/:vendorId/commission", controller.setVendorCommission);
router.patch("/users/:userId/loyalty", controller.updateUserLoyalty);
router.patch("/users/:userId/referral-rewards", controller.updateUserReferralRewards);
router.post("/coupons", controller.createCoupon);
router.get("/support-queries", controller.listSupportQueries);
router.get("/inventory-alerts", controller.getInventoryAlerts);

module.exports = router;
