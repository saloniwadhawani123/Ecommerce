const express = require("express");
const { protect, authorize } = require("../middlewares/auth");
const userController = require("../controllers/userController");
const roles = require("../constants/roles");

const router = express.Router();

router.use(protect, authorize(roles.USER, roles.VENDOR, roles.ADMIN));
router.patch("/profile", userController.updateProfile);
router.get("/wishlist", userController.getWishlist);
router.post("/wishlist/:productId", userController.toggleWishlist);
router.get("/daily-reward/status", userController.getDailyRewardStatus);
router.post("/daily-reward/claim", userController.claimDailyReward);

module.exports = router;
