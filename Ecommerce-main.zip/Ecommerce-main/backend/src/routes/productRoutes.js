const express = require("express");
const { protect, authorize } = require("../middlewares/auth");
const roles = require("../constants/roles");
const controller = require("../controllers/productController");

const router = express.Router();

router.get("/", controller.getProducts);
router.get("/mine", protect, authorize(roles.VENDOR, roles.ADMIN), controller.listMyProducts);
router.get("/:slug", controller.getProductBySlug);
router.post("/:id/reviews", protect, authorize(roles.USER, roles.VENDOR, roles.ADMIN), controller.addReview);
router.post("/", protect, authorize(roles.ADMIN, roles.VENDOR), controller.createProduct);
router.patch("/:id", protect, authorize(roles.ADMIN, roles.VENDOR), controller.updateProduct);
router.delete("/:id", protect, authorize(roles.ADMIN, roles.VENDOR), controller.deleteProduct);

module.exports = router;
