const express = require("express");
const { protect, authorize } = require("../middlewares/auth");
const roles = require("../constants/roles");
const controller = require("../controllers/vendorController");

const router = express.Router();

router.use(protect, authorize(roles.VENDOR));
router.get("/dashboard", controller.vendorDashboard);

module.exports = router;
