const express = require("express");
const { terms, privacy } = require("../controllers/legalController");

const router = express.Router();

router.get("/terms", terms);
router.get("/privacy", privacy);

module.exports = router;
