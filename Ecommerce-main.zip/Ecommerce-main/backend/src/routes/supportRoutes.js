const express = require("express");
const { createQuery } = require("../controllers/supportController");

const router = express.Router();

router.post("/contact", createQuery);

module.exports = router;
