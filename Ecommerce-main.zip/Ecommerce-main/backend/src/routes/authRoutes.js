const express = require("express");
const { z } = require("zod");
const validate = require("../middlewares/validate");
const { protect } = require("../middlewares/auth");
const controller = require("../controllers/authController");

const router = express.Router();

const registerSchema = z.object({
  body: z.object({
    name: z.string().min(2),
    email: z.string().email(),
    password: z.string().min(8),
    role: z.enum(["user", "vendor"]).optional(),
    referralCode: z.string().optional(),
    vendorProfile: z
      .object({
        storeName: z.string().optional(),
        bio: z.string().optional(),
      })
      .optional(),
  }),
  params: z.object({}).optional(),
  query: z.object({}).optional(),
});

const loginSchema = z.object({
  body: z.object({
    email: z.string().email(),
    password: z.string().min(8),
    otp: z.string().length(6).optional(),
    role: z.enum(["user", "vendor", "admin"]).optional(),
  }),
  params: z.object({}).optional(),
  query: z.object({}).optional(),
});

router.get("/csrf-token", controller.csrfToken);
router.post("/register", validate(registerSchema), controller.register);
router.post("/login", validate(loginSchema), controller.login);
router.post("/logout", protect, controller.logout);
router.get("/me", protect, controller.me);
router.post("/2fa/request", protect, controller.requestEnable2FA);
router.post("/2fa/verify", protect, controller.verifyEnable2FA);
router.post("/google", controller.googleAuthPlaceholder);

module.exports = router;
