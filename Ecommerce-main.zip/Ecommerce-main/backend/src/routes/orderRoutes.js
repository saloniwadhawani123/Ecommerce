const express = require("express");
const { protect, authorize } = require("../middlewares/auth");
const roles = require("../constants/roles");
const controller = require("../controllers/orderController");

const router = express.Router();

router.use(protect, authorize(roles.USER, roles.VENDOR, roles.ADMIN));
router.post("/checkout", controller.checkout);
router.get("/my-orders", controller.getMyOrders);

module.exports = router;
