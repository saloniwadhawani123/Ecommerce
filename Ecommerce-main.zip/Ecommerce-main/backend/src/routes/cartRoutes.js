const express = require("express");
const { protect, authorize } = require("../middlewares/auth");
const roles = require("../constants/roles");
const controller = require("../controllers/cartController");

const router = express.Router();

router.use(protect, authorize(roles.USER, roles.VENDOR, roles.ADMIN));
router.get("/", controller.getCart);
router.post("/", controller.addToCart);
router.patch("/:productId", controller.updateCartItem);
router.delete("/:productId", controller.removeCartItem);

module.exports = router;
