const EARN_RATE = 10; // 1 point per 10 currency units
const REDEEM_VALUE = 0.2; // 1 point = 0.2 currency units

const earnedPoints = (orderValue) => Math.floor(orderValue / EARN_RATE);
const redeemAmountFromPoints = (points) => Number((points * REDEEM_VALUE).toFixed(2));

module.exports = { EARN_RATE, REDEEM_VALUE, earnedPoints, redeemAmountFromPoints };
