const jwt = require("jsonwebtoken");
const env = require("../config/env");

const signToken = (payload, expiresIn = env.jwtExpiresIn) =>
  jwt.sign(payload, env.jwtSecret, { expiresIn });

const setAuthCookie = (res, token) => {
  res.cookie("token", token, {
    httpOnly: true,
    secure: env.nodeEnv === "production",
    sameSite: env.nodeEnv === "production" ? "none" : "lax",
    maxAge: env.jwtCookieExpiresInDays * 24 * 60 * 60 * 1000,
  });
};

module.exports = { signToken, setAuthCookie };
