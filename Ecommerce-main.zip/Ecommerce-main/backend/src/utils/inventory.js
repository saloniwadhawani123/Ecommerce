const getLowStockProducts = (products = []) =>
  products.filter((product) => product.stock <= product.lowStockThreshold);

module.exports = { getLowStockProducts };
