const calculateCommission = (lineTotal, commissionRate = 12) => {
  const fee = (lineTotal * commissionRate) / 100;
  return Number(fee.toFixed(2));
};

module.exports = { calculateCommission };
