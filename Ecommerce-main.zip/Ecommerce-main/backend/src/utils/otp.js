const otpGenerator = require("otp-generator");

const generateOtpCode = () =>
  otpGenerator.generate(6, {
    upperCaseAlphabets: false,
    lowerCaseAlphabets: false,
    specialChars: false,
  });

module.exports = { generateOtpCode };
