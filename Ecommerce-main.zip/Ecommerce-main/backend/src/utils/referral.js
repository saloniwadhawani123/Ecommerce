const crypto = require("crypto");

const generateReferralCode = (name = "USR") => {
  const prefix = name.replace(/[^a-z]/gi, "").slice(0, 3).toUpperCase() || "KAL";
  return `${prefix}${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
};

module.exports = { generateReferralCode };
