class APIFeatures {
  constructor(query, queryString) {
    this.query = query;
    this.queryString = queryString;
  }

  search() {
    if (this.queryString.search) {
      this.query = this.query.find({
        $text: { $search: this.queryString.search },
      });
    }
    return this;
  }

  filter() {
    const filters = {};

    if (this.queryString.category) filters.category = this.queryString.category;
    if (this.queryString.minRating) {
      filters.averageRating = { $gte: Number(this.queryString.minRating) };
    }

    if (this.queryString.minPrice || this.queryString.maxPrice) {
      filters.price = {};
      if (this.queryString.minPrice) {
        filters.price.$gte = Number(this.queryString.minPrice);
      }
      if (this.queryString.maxPrice) {
        filters.price.$lte = Number(this.queryString.maxPrice);
      }
    }

    this.query = this.query.find(filters);
    return this;
  }

  sort() {
    const allowed = {
      popularity: "-popularity",
      newest: "-createdAt",
      price_asc: "price",
      price_desc: "-price",
      rating: "-averageRating",
    };

    const sortBy = allowed[this.queryString.sort] || "-priority -createdAt";
    this.query = this.query.sort(sortBy);
    return this;
  }

  paginate() {
    const page = Number(this.queryString.page) || 1;
    const limit = Number(this.queryString.limit) || 12;
    const skip = (page - 1) * limit;

    this.query = this.query.skip(skip).limit(limit);
    this.pagination = { page, limit };
    return this;
  }
}

module.exports = APIFeatures;
