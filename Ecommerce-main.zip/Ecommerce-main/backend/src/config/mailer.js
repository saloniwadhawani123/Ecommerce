const nodemailer = require("nodemailer");
const env = require("./env");

const transporter = env.smtpHost
  ? nodemailer.createTransport({
      host: env.smtpHost,
      port: env.smtpPort,
      secure: env.smtpPort === 465,
      auth: {
        user: env.smtpUser,
        pass: env.smtpPass,
      },
    })
  : nodemailer.createTransport({ jsonTransport: true });

const sendMail = async ({ to, subject, html }) => {
  const info = await transporter.sendMail({
    from: env.smtpFrom,
    to,
    subject,
    html,
  });

  if (!env.smtpHost) {
    console.log("Email preview (jsonTransport):", info.message);
  }

  return info;
};

module.exports = { sendMail };
