const mongoose = require("mongoose");
const env = require("./env");

const connectDB = async () => {
  mongoose.set("strictQuery", true);
  let lastError;

  for (const uri of env.mongoUris) {
    try {
      await mongoose.connect(uri, {
        serverSelectionTimeoutMS: env.mongoConnectTimeoutMs,
      });
      console.log(`MongoDB connected (${uri})`);
      return;
    } catch (error) {
      lastError = error;
      console.warn(`MongoDB connection failed for ${uri}: ${error.message}`);
    }
  }

  throw lastError || new Error("Unable to connect to MongoDB");
};

module.exports = connectDB;
