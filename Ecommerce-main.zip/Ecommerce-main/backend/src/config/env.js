const dotenv = require("dotenv");

dotenv.config();

const parseCsv = (value) =>
  String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

const configuredMongoUris = parseCsv(process.env.MONGO_URIS);
if (!configuredMongoUris.length && process.env.MONGO_URI) {
  configuredMongoUris.push(process.env.MONGO_URI);
}

const localMongoUri = "mongodb://127.0.0.1:27017/kalakriti";
if (!configuredMongoUris.length) {
  configuredMongoUris.push(localMongoUri);
}

// In non-production, include local Mongo as a safety fallback if Atlas is unreachable.
if ((process.env.NODE_ENV || "development") !== "production" && !configuredMongoUris.includes(localMongoUri)) {
  configuredMongoUris.push(localMongoUri);
}

const required = ["JWT_SECRET"];
required.forEach((key) => {
  if (!process.env[key]) {
    // Fail fast for critical secrets in production-like environments.
    if (process.env.NODE_ENV === "production") {
      throw new Error(`Missing required environment variable: ${key}`);
    }
  }
});

if (!configuredMongoUris.length && process.env.NODE_ENV === "production") {
  throw new Error("Missing required MongoDB configuration: set MONGO_URI or MONGO_URIS");
}

module.exports = {
  nodeEnv: process.env.NODE_ENV || "development",
  port: Number(process.env.PORT || 5000),
  mongoUri: configuredMongoUris[0],
  mongoUris: configuredMongoUris,
  mongoConnectTimeoutMs: Number(process.env.MONGO_CONNECT_TIMEOUT_MS || 8000),
  jwtSecret: process.env.JWT_SECRET || "dev-jwt-secret-change-me",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "7d",
  jwtCookieExpiresInDays: Number(process.env.JWT_COOKIE_EXPIRES_IN_DAYS || 7),
  clientUrl: process.env.CLIENT_URL || "http://localhost:5173",
  smtpHost: process.env.SMTP_HOST || "",
  smtpPort: Number(process.env.SMTP_PORT || 587),
  smtpUser: process.env.SMTP_USER || "",
  smtpPass: process.env.SMTP_PASS || "",
  smtpFrom: process.env.SMTP_FROM || "Kalakriti <no-reply@kalakriti.local>",
  razorpayKeyId: process.env.RAZORPAY_KEY_ID || "",
  razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || "",
};
