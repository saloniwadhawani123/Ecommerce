const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const env = require("./config/env");

const securityStack = require("./middlewares/security");
const { ensureCsrfCookie, verifyCsrf } = require("./middlewares/csrf");
const { notFound, errorHandler } = require("./middlewares/errorHandler");

const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");
const productRoutes = require("./routes/productRoutes");
const cartRoutes = require("./routes/cartRoutes");
const orderRoutes = require("./routes/orderRoutes");
const vendorRoutes = require("./routes/vendorRoutes");
const adminRoutes = require("./routes/adminRoutes");
const supportRoutes = require("./routes/supportRoutes");
const legalRoutes = require("./routes/legalRoutes");

const app = express();

/* =========================
    CORS
========================= */
const normalizeOrigin = (value) => String(value || "").trim().replace(/\/+$/, "");

app.use(
   cors({
      origin: (origin, callback) => {
         if (!origin) return callback(null, true);

         const normalizedOrigin = normalizeOrigin(origin);
         const configuredOrigins = String(env.clientUrl || "")
            .split(",")
            .map(normalizeOrigin)
            .filter(Boolean);

         const allowed = new Set([
            ...configuredOrigins,
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "http://localhost:3000",
         ]);

         const isLocalDevOrigin = /^https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/i.test(
            normalizedOrigin
         );
         const isLanOrigin = /^https?:\/\/(\d{1,3}\.){3}\d{1,3}(:\d+)?$/i.test(normalizedOrigin);
         const isRenderOrigin = /^https:\/\/[a-z0-9-]+\.onrender\.com$/i.test(normalizedOrigin);

         if (allowed.has(normalizedOrigin) || isLocalDevOrigin || isLanOrigin || isRenderOrigin) {
            return callback(null, true);
         }

         return callback(new Error("Not allowed by CORS"));
      },
      credentials: true,
   })
);

/* =========================
   Middlewares
========================= */
securityStack(app);

app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(morgan("dev"));

/* =========================
   CSRF
========================= */
if (process.env.NODE_ENV !== "production") {
  app.use(ensureCsrfCookie);
  app.use(verifyCsrf);
}

/* =========================
   Routes
========================= */
app.get("/", (_req, res) => {
  res.json({ message: "Kalakriti API running" });
});

app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/users", userRoutes);
app.use("/api/v1/products", productRoutes);
app.use("/api/v1/cart", cartRoutes);
app.use("/api/v1/orders", orderRoutes);
app.use("/api/v1/vendors", vendorRoutes);
app.use("/api/v1/admin", adminRoutes);
app.use("/api/v1/support", supportRoutes);
app.use("/api/v1/legal", legalRoutes);

/* =========================
   Error Handling
========================= */
app.use(notFound);
app.use(errorHandler);

module.exports = app;
