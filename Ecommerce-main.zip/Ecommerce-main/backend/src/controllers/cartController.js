const Product = require("../models/Product");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/appError");

const getCart = asyncHandler(async (req, res) => {
  await req.user.populate("cart.product");
  res.json({ cart: req.user.cart });
});

const addToCart = asyncHandler(async (req, res, next) => {
  const { productId, quantity = 1 } = req.body;
  const product = await Product.findById(productId);
  if (!product) return next(new AppError("Product not found", 404));
  if (product.stock < quantity) return next(new AppError("Insufficient stock", 400));

  const existing = req.user.cart.find((item) => item.product.toString() === productId);
  if (existing) {
    existing.quantity += quantity;
  } else {
    req.user.cart.push({ product: productId, quantity });
  }

  await req.user.save();
  await req.user.populate("cart.product");
  res.json({ message: "Added to cart", cart: req.user.cart });
});

const updateCartItem = asyncHandler(async (req, res, next) => {
  const { productId } = req.params;
  const { quantity } = req.body;
  const item = req.user.cart.find((cartItem) => cartItem.product.toString() === productId);
  if (!item) return next(new AppError("Cart item not found", 404));

  item.quantity = Math.max(1, Number(quantity));
  await req.user.save();
  await req.user.populate("cart.product");

  res.json({ message: "Cart updated", cart: req.user.cart });
});

const removeCartItem = asyncHandler(async (req, res) => {
  const { productId } = req.params;
  req.user.cart = req.user.cart.filter((item) => item.product.toString() !== productId);
  await req.user.save();
  await req.user.populate("cart.product");
  res.json({ message: "Removed from cart", cart: req.user.cart });
});

module.exports = { getCart, addToCart, updateCartItem, removeCartItem };
