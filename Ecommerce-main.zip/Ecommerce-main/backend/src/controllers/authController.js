const jwt = require("jsonwebtoken");
const User = require("../models/User");
const OTP = require("../models/OTP");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/appError");
const { signToken } = require("../utils/generateToken");
const { isStrongPassword } = require("../utils/password");
const { generateOtpCode } = require("../utils/otp");
const { sendMail } = require("../config/mailer");
const { generateReferralCode } = require("../utils/referral");
const env = require("../config/env");

/* =========================
   Helpers
========================= */

const createUniqueReferral = async (name) => {
  for (let i = 0; i < 5; i += 1) {
    const code = generateReferralCode(name);
    const exists = await User.findOne({ referralCode: code });
    if (!exists) return code;
  }
  return `${Date.now()}`;
};

/* =========================
   ✅ FIXED AUTH RESPONSE
========================= */
const sendAuthResponse = (res, user) => {
  const token = signToken({ id: user._id, role: user.role });

  res.cookie("token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production", // 🔥 IMPORTANT
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax", // 🔥 IMPORTANT
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });

  res.json({
    message: "Authentication successful",
    token,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      loyaltyPoints: user.loyaltyPoints,
      referralCode: user.referralCode,
      twoFactorEnabled: user.twoFactorEnabled,
    },
  });
};

/* =========================
   Register
========================= */
const register = asyncHandler(async (req, res, next) => {
  const { name, email, password, role = "user", referralCode, vendorProfile } = req.body;

  if (!isStrongPassword(password)) {
    return next(
      new AppError(
        "Password must include uppercase, lowercase, number, and special character.",
        400
      )
    );
  }

  const existingUser = await User.findOne({ email });
  if (existingUser) return next(new AppError("Email already in use", 409));

  const userData = {
    name,
    email,
    password,
    role: role === "vendor" ? "vendor" : "user",
    referralCode: await createUniqueReferral(name),
  };

  if (role === "vendor") {
    userData.vendorProfile = {
      storeName: vendorProfile?.storeName || `${name}'s Atelier`,
      bio: vendorProfile?.bio || "Handcrafted creations.",
      commissionRate: 12,
    };
  }

  if (referralCode) {
    const referrer = await User.findOne({ referralCode });
    if (referrer) {
      userData.referredBy = referrer._id;
      referrer.loyaltyPoints += 20;
      referrer.referralRewards += 20;
      await referrer.save();
    }
  }

  const user = await User.create(userData);
  sendAuthResponse(res, user);
});

/* =========================
   Login
========================= */
const login = asyncHandler(async (req, res, next) => {
  const { email, password, otp, role } = req.body;
  const user = await User.findOne({ email }).select("+password");

  if (!user || !(await user.comparePassword(password))) {
    return next(new AppError("Invalid credentials", 401));
  }

  if (role && user.role !== role) {
    return next(new AppError(`This account is not a ${role} account`, 403));
  }

  if (user.twoFactorEnabled) {
    if (!otp) {
      const code = generateOtpCode();
      await OTP.create({
        user: user._id,
        email: user.email,
        otp: code,
        purpose: "login2fa",
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      });

      await sendMail({
        to: user.email,
        subject: "Kalakriti Login OTP",
        html: `<p>Your login OTP is <b>${code}</b>. It is valid for 10 minutes.</p>`,
      });

      return res.status(202).json({ message: "OTP sent to email", requires2FA: true });
    }

    const validOtp = await OTP.findOne({
      email: user.email,
      otp,
      purpose: "login2fa",
      expiresAt: { $gt: new Date() },
    });

    if (!validOtp) return next(new AppError("Invalid or expired OTP", 401));
    await OTP.deleteMany({ email: user.email, purpose: "login2fa" });
  }

  sendAuthResponse(res, user);
});

/* =========================
   Logout (FIXED)
========================= */
const logout = asyncHandler(async (_req, res) => {
  res.cookie("token", "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
    expires: new Date(0),
  });

  res.json({ message: "Logged out" });
});

/* =========================
   Other Controllers
========================= */
const requestEnable2FA = asyncHandler(async (req, res) => {
  const code = generateOtpCode();
  await OTP.create({
    user: req.user._id,
    email: req.user.email,
    otp: code,
    purpose: "enable2fa",
    expiresAt: new Date(Date.now() + 10 * 60 * 1000),
  });

  await sendMail({
    to: req.user.email,
    subject: "Enable 2FA OTP",
    html: `<p>Your OTP to enable 2FA is <b>${code}</b>.</p>`,
  });

  res.json({ message: "2FA OTP sent" });
});

const verifyEnable2FA = asyncHandler(async (req, res, next) => {
  const { otp } = req.body;
  const validOtp = await OTP.findOne({
    email: req.user.email,
    otp,
    purpose: "enable2fa",
    expiresAt: { $gt: new Date() },
  });

  if (!validOtp) return next(new AppError("Invalid or expired OTP", 400));

  req.user.twoFactorEnabled = true;
  await req.user.save();
  await OTP.deleteMany({ email: req.user.email, purpose: "enable2fa" });

  res.json({ message: "2FA enabled" });
});

const me = asyncHandler(async (req, res) => {
  res.json({ user: req.user });
});

const csrfToken = asyncHandler(async (req, res) => {
  res.json({ csrfToken: req.csrfToken });
});

const googleAuthPlaceholder = asyncHandler(async (_req, res) => {
  res.json({
    message:
      "Google OAuth endpoint placeholder. Configure Google client credentials and token verification to enable.",
  });
});

const verifyToken = (token) => jwt.verify(token, env.jwtSecret);

module.exports = {
  register,
  login,
  requestEnable2FA,
  verifyEnable2FA,
  me,
  logout,
  csrfToken,
  googleAuthPlaceholder,
  verifyToken,
};