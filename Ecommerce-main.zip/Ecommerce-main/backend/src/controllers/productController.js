const Product = require("../models/Product");
const APIFeatures = require("../utils/apiFeatures");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/appError");

const slugify = (value) => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-");

const getProducts = asyncHandler(async (req, res) => {
  let features = new APIFeatures(
    Product.find({ approvalStatus: "approved" }),
    req.query
  )
    .search()
    .filter()
    .sort()
    .paginate();

  let products = await features.query.populate("vendor", "name vendorProfile.storeName");

  // Fresh production databases may contain only pending/unreviewed products.
  // If no approved items are available, gracefully fall back to all products.
  if (!products.length) {
    features = new APIFeatures(Product.find({}), req.query).search().filter().sort().paginate();
    products = await features.query.populate("vendor", "name vendorProfile.storeName");
  }

  res.json({ products, pagination: features.pagination });
});

const getProductBySlug = asyncHandler(async (req, res, next) => {
  let product = await Product.findOne({
    slug: req.params.slug,
    approvalStatus: "approved",
  }).populate("vendor", "name vendorProfile");

  if (!product) {
    product = await Product.findOne({ slug: req.params.slug }).populate("vendor", "name vendorProfile");
  }

  if (!product) return next(new AppError("Product not found", 404));
  res.json({ product });
});

const createProduct = asyncHandler(async (req, res) => {
  const payload = { ...req.body };
  payload.slug = payload.slug || slugify(payload.title);

  if (req.user.role === "vendor") {
    payload.vendor = req.user._id;
    payload.isPlatformProduct = false;
    payload.approvalStatus = "pending";
  } else {
    payload.isPlatformProduct = payload.isPlatformProduct ?? true;
    payload.approvalStatus = "approved";
    payload.approvedBy = req.user._id;
    payload.approvedAt = new Date();
  }

  const product = await Product.create(payload);
  res.status(201).json({ message: "Product created", product });
});

const updateProduct = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError("Product not found", 404));

  if (req.user.role === "vendor" && product.vendor?.toString() !== req.user._id.toString()) {
    return next(new AppError("Vendors can only edit their own products", 403));
  }

  Object.assign(product, req.body);
  if (req.body.title && !req.body.slug) {
    product.slug = slugify(req.body.title);
  }

  if (req.user.role === "vendor") {
    product.approvalStatus = "pending";
    product.approvedBy = undefined;
    product.approvedAt = undefined;
    product.rejectionReason = undefined;
  }

  await product.save();
  res.json({ message: "Product updated", product });
});

const deleteProduct = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError("Product not found", 404));

  if (req.user.role === "vendor" && product.vendor?.toString() !== req.user._id.toString()) {
    return next(new AppError("Vendors can only delete their own products", 403));
  }

  await product.deleteOne();
  res.json({ message: "Product deleted" });
});

const addReview = asyncHandler(async (req, res, next) => {
  const { rating, comment } = req.body;
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError("Product not found", 404));

  product.reviews.push({ user: req.user._id, rating, comment });
  const ratings = product.reviews.map((r) => r.rating);
  product.totalRatings = ratings.length;
  product.averageRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;
  await product.save();

  res.status(201).json({ message: "Review added", product });
});

const listMyProducts = asyncHandler(async (req, res) => {
  const query = req.user.role === "vendor" ? { vendor: req.user._id } : {};
  const products = await Product.find(query).sort({ createdAt: -1 });
  res.json({ products });
});

module.exports = {
  getProducts,
  getProductBySlug,
  createProduct,
  updateProduct,
  deleteProduct,
  addReview,
  listMyProducts,
};
