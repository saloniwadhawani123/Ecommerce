const ContactQuery = require("../models/ContactQuery");
const asyncHandler = require("../utils/asyncHandler");

const createQuery = asyncHandler(async (req, res) => {
  const query = await ContactQuery.create(req.body);
  res.status(201).json({ message: "Support query submitted", query });
});

module.exports = { createQuery };
