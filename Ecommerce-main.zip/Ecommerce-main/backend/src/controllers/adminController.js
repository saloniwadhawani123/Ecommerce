const User = require("../models/User");
const Product = require("../models/Product");
const Order = require("../models/Order");
const Coupon = require("../models/Coupon");
const ContactQuery = require("../models/ContactQuery");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/appError");
const { getLowStockProducts } = require("../utils/inventory");

const getDashboardAnalytics = asyncHandler(async (_req, res) => {
  const [users, vendors, products, orders] = await Promise.all([
    User.countDocuments({ role: "user" }),
    User.countDocuments({ role: "vendor" }),
    Product.countDocuments(),
    Order.find(),
  ]);

  const grossRevenue = orders.reduce((sum, order) => sum + order.total, 0);

  res.json({
    analytics: {
      users,
      vendors,
      products,
      totalOrders: orders.length,
      grossRevenue,
    },
  });
});

const listUsers = asyncHandler(async (_req, res) => {
  const users = await User.find().select("-password");
  res.json({ users });
});

const listOrders = asyncHandler(async (_req, res) => {
  const orders = await Order.find().sort({ createdAt: -1 }).populate("user", "name email");
  res.json({ orders });
});

const setProductPriority = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.productId);
  if (!product) return next(new AppError("Product not found", 404));

  product.priority = Number(req.body.priority || 0);
  product.isFeatured = Boolean(req.body.isFeatured);
  product.promotedUntil = req.body.promotedUntil || null;
  await product.save();

  res.json({ message: "Product priority updated", product });
});

const setVendorCommission = asyncHandler(async (req, res, next) => {
  const vendor = await User.findById(req.params.vendorId);
  if (!vendor || vendor.role !== "vendor") {
    return next(new AppError("Vendor not found", 404));
  }

  vendor.vendorProfile.commissionRate = Number(req.body.commissionRate || 12);
  await vendor.save();
  res.json({ message: "Commission updated", vendor });
});

const createCoupon = asyncHandler(async (req, res) => {
  const coupon = await Coupon.create(req.body);
  res.status(201).json({ message: "Coupon created", coupon });
});

const listSupportQueries = asyncHandler(async (_req, res) => {
  const queries = await ContactQuery.find().sort({ createdAt: -1 });
  res.json({ queries });
});

const getInventoryAlerts = asyncHandler(async (_req, res) => {
  const products = await Product.find().select("title stock lowStockThreshold isPlatformProduct vendor");
  const lowStock = getLowStockProducts(products);
  res.json({ lowStock });
});

const listProducts = asyncHandler(async (_req, res) => {
  const products = await Product.find()
    .sort({ priority: -1, createdAt: -1 })
    .populate("vendor", "name email vendorProfile.storeName");

  res.json({ products });
});

const listPendingProducts = asyncHandler(async (_req, res) => {
  const pendingProducts = await Product.find({ approvalStatus: "pending" })
    .sort({ createdAt: -1 })
    .populate("vendor", "name email vendorProfile.storeName");

  res.json({ pendingProducts });
});

const reviewProductApproval = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.productId);
  if (!product) return next(new AppError("Product not found", 404));

  const { status, rejectionReason } = req.body;
  if (!["approved", "rejected"].includes(status)) {
    return next(new AppError("Invalid approval status", 400));
  }

  product.approvalStatus = status;
  product.approvedBy = req.user._id;
  product.approvedAt = status === "approved" ? new Date() : undefined;
  product.rejectionReason = status === "rejected" ? rejectionReason || "Rejected by admin" : undefined;
  await product.save();

  res.json({ message: `Product ${status}`, product });
});

const listVendors = asyncHandler(async (_req, res) => {
  const vendors = await User.find({ role: "vendor" }).select(
    "name email vendorProfile referralCode loyaltyPoints referralRewards"
  );
  res.json({ vendors });
});

const updateOrderStatus = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.orderId);
  if (!order) return next(new AppError("Order not found", 404));

  if (req.body.orderStatus) order.orderStatus = req.body.orderStatus;
  if (req.body.paymentStatus) order.paymentStatus = req.body.paymentStatus;
  await order.save();

  res.json({ message: "Order updated", order });
});

const updateUserLoyalty = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.params.userId);
  if (!user) return next(new AppError("User not found", 404));

  user.loyaltyPoints = Math.max(0, Number(req.body.loyaltyPoints || 0));
  await user.save();

  res.json({ message: "Loyalty points updated", user });
});

const updateUserReferralRewards = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.params.userId);
  if (!user) return next(new AppError("User not found", 404));

  user.referralRewards = Math.max(0, Number(req.body.referralRewards || 0));
  await user.save();

  res.json({ message: "Referral rewards updated", user });
});

module.exports = {
  getDashboardAnalytics,
  listUsers,
  listOrders,
  listProducts,
  listPendingProducts,
  listVendors,
  setProductPriority,
  setVendorCommission,
  reviewProductApproval,
  updateOrderStatus,
  updateUserLoyalty,
  updateUserReferralRewards,
  createCoupon,
  listSupportQueries,
  getInventoryAlerts,
};
