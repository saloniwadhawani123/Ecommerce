const User = require("../models/User");
const Product = require("../models/Product");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/appError");

const startOfUtcDay = (date) =>
  new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));

const getNextUtcDay = (date) => {
  const next = startOfUtcDay(date);
  next.setUTCDate(next.getUTCDate() + 1);
  return next;
};

const updateProfile = asyncHandler(async (req, res) => {
  const fields = ["name", "phone", "avatar", "addresses"];
  fields.forEach((field) => {
    if (req.body[field] !== undefined) req.user[field] = req.body[field];
  });

  await req.user.save();
  res.json({ message: "Profile updated", user: req.user });
});

const getWishlist = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate("wishlist");
  res.json({ wishlist: user.wishlist });
});

const toggleWishlist = asyncHandler(async (req, res, next) => {
  const { productId } = req.params;
  const product = await Product.findById(productId);
  if (!product) return next(new AppError("Product not found", 404));

  const index = req.user.wishlist.findIndex((id) => id.toString() === productId);
  if (index >= 0) {
    req.user.wishlist.splice(index, 1);
  } else {
    req.user.wishlist.push(productId);
  }

  await req.user.save();
  res.json({ message: "Wishlist updated", wishlist: req.user.wishlist });
});

const getDailyRewardStatus = asyncHandler(async (req, res, next) => {
  if (req.user.role !== "user") return next(new AppError("Daily reward is for customers only", 403));

  const now = new Date();
  const todayStart = startOfUtcDay(now);
  const lastClaim = req.user.lastDailyRewardAt ? new Date(req.user.lastDailyRewardAt) : null;
  const claimedToday = lastClaim && lastClaim >= todayStart;

  res.json({
    eligible: !claimedToday,
    streak: req.user.dailyRewardStreak || 0,
    nextClaimAt: claimedToday ? getNextUtcDay(now) : now,
  });
});

const claimDailyReward = asyncHandler(async (req, res, next) => {
  if (req.user.role !== "user") return next(new AppError("Daily reward is for customers only", 403));

  const now = new Date();
  const todayStart = startOfUtcDay(now);
  const yesterdayStart = new Date(todayStart);
  yesterdayStart.setUTCDate(yesterdayStart.getUTCDate() - 1);

  const lastClaim = req.user.lastDailyRewardAt ? new Date(req.user.lastDailyRewardAt) : null;
  if (lastClaim && lastClaim >= todayStart) {
    return next(new AppError("Daily reward already claimed today", 400));
  }

  const continuedStreak = lastClaim && lastClaim >= yesterdayStart && lastClaim < todayStart;
  const newStreak = continuedStreak ? (req.user.dailyRewardStreak || 0) + 1 : 1;

  const basePoints = 10;
  const streakBonus = Math.min(newStreak, 7) * 2;
  const rewardPoints = basePoints + streakBonus;

  req.user.dailyRewardStreak = newStreak;
  req.user.lastDailyRewardAt = now;
  req.user.loyaltyPoints += rewardPoints;
  await req.user.save();

  res.json({
    message: "Daily reward claimed",
    rewardPoints,
    streak: newStreak,
    loyaltyPoints: req.user.loyaltyPoints,
    nextClaimAt: getNextUtcDay(now),
  });
});

module.exports = {
  updateProfile,
  getWishlist,
  toggleWishlist,
  getDailyRewardStatus,
  claimDailyReward,
};
