const User = require("../models/User");
const Product = require("../models/Product");
const Order = require("../models/Order");
const Coupon = require("../models/Coupon");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/appError");
const { calculateCommission } = require("../utils/commission");
const { earnedPoints, redeemAmountFromPoints } = require("../utils/loyalty");

const checkout = asyncHandler(async (req, res, next) => {
  const { shippingAddress, paymentMethod = "mock", couponCode, redeemPoints = 0, paymentDetails = {} } = req.body;
  await req.user.populate("cart.product");

  const allowedMethods = ["mock", "razorpay", "cod", "upi", "card"];
  if (!allowedMethods.includes(paymentMethod)) {
    return next(new AppError("Unsupported payment method", 400));
  }

  if (paymentMethod === "upi" && !paymentDetails.upiId) {
    return next(new AppError("UPI ID is required for UPI payment", 400));
  }

  if (paymentMethod === "card" && !paymentDetails.cardNumber) {
    return next(new AppError("Card number is required for card payment", 400));
  }

  if (!req.user.cart.length) return next(new AppError("Cart is empty", 400));

  let subtotal = 0;
  const orderItems = [];
  let trackingType = "platform";

  for (const cartItem of req.user.cart) {
    const product = cartItem.product;
    if (!product || product.stock < cartItem.quantity) {
      return next(new AppError(`Insufficient stock for ${product?.title || "a product"}`, 400));
    }

    const unitPrice = product.discountPrice || product.price;
    const lineTotal = unitPrice * cartItem.quantity;
    subtotal += lineTotal;

    const isVendorProduct = !product.isPlatformProduct && product.vendor;
    if (isVendorProduct && trackingType === "platform") trackingType = "vendor";
    if (!isVendorProduct && trackingType === "vendor") trackingType = "mixed";

    let commissionRate = 0;
    let commissionAmount = 0;

    if (isVendorProduct) {
      const vendor = await User.findById(product.vendor);
      commissionRate = vendor?.vendorProfile?.commissionRate || 12;
      commissionAmount = calculateCommission(lineTotal, commissionRate);

      if (vendor) {
        vendor.vendorProfile.earnings += lineTotal - commissionAmount;
        vendor.vendorProfile.totalSales += lineTotal;
        await vendor.save();
      }
    }

    product.stock -= cartItem.quantity;
    product.popularity += cartItem.quantity;
    await product.save();

    orderItems.push({
      product: product._id,
      titleSnapshot: product.title,
      price: unitPrice,
      quantity: cartItem.quantity,
      vendor: product.vendor,
      commissionRate,
      commissionAmount,
      lineTotal,
    });
  }

  let discount = 0;
  if (couponCode) {
    const coupon = await Coupon.findOne({ code: couponCode.toUpperCase(), active: true });
    const validDate = !coupon?.expiresAt || coupon.expiresAt > new Date();
    if (coupon && validDate && coupon.usedCount < coupon.usageLimit && subtotal >= coupon.minOrderValue) {
      if (coupon.type === "percent") {
        discount = (subtotal * coupon.value) / 100;
        if (coupon.maxDiscount) discount = Math.min(discount, coupon.maxDiscount);
      } else {
        discount = coupon.value;
      }
      coupon.usedCount += 1;
      await coupon.save();
    }
  }

  const usablePoints = Math.min(req.user.loyaltyPoints, Number(redeemPoints || 0));
  const loyaltyAmount = redeemAmountFromPoints(usablePoints);
  const shippingFee = subtotal > 1500 ? 0 : 99;
  const total = Math.max(0, subtotal - discount - loyaltyAmount + shippingFee);

  req.user.loyaltyPoints -= usablePoints;
  req.user.loyaltyPoints += earnedPoints(total);
  req.user.cart = [];
  await req.user.save();

  let paymentStatus = "pending";
  if (["mock", "upi", "card"].includes(paymentMethod)) {
    paymentStatus = "paid";
  }

  const paymentMeta = {
    provider: paymentMethod,
  };

  if (paymentMethod === "upi") {
    paymentMeta.upiId = paymentDetails.upiId;
  }

  if (paymentMethod === "card") {
    const digits = String(paymentDetails.cardNumber || "").replace(/\D/g, "");
    paymentMeta.cardLast4 = digits.slice(-4);
  }

  const order = await Order.create({
    user: req.user._id,
    items: orderItems,
    shippingAddress,
    paymentMethod,
    paymentStatus,
    paymentMeta,
    subtotal,
    discount,
    shippingFee,
    loyaltyRedeemed: usablePoints,
    couponCode,
    total,
    trackingType,
  });

  res.status(201).json({ message: "Order placed", order });
});

const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json({ orders });
});

module.exports = { checkout, getMyOrders };
