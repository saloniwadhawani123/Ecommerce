const Order = require("../models/Order");
const Product = require("../models/Product");
const asyncHandler = require("../utils/asyncHandler");

const vendorDashboard = asyncHandler(async (req, res) => {
  const vendorId = req.user._id;

  const products = await Product.find({ vendor: vendorId });
  const orders = await Order.find({ "items.vendor": vendorId })
    .sort({ createdAt: -1 })
    .populate("user", "name email");

  const earnings = req.user.vendorProfile?.earnings || 0;
  const totalSales = req.user.vendorProfile?.totalSales || 0;

  const vendorOrders = orders.map((order) => {
    const vendorItems = order.items.filter(
      (item) => item.vendor && item.vendor.toString() === vendorId.toString()
    );

    const gross = vendorItems.reduce((sum, item) => sum + item.lineTotal, 0);
    const commission = vendorItems.reduce((sum, item) => sum + item.commissionAmount, 0);

    return {
      _id: order._id,
      createdAt: order.createdAt,
      orderStatus: order.orderStatus,
      paymentStatus: order.paymentStatus,
      customer: order.user,
      items: vendorItems,
      gross,
      commission,
      net: gross - commission,
    };
  });

  res.json({
    metrics: {
      totalProducts: products.length,
      orders: vendorOrders.length,
      earnings,
      totalSales,
    },
    products,
    orders: vendorOrders,
  });
});

module.exports = { vendorDashboard };
