const asyncHandler = require("../utils/asyncHandler");

const terms = asyncHandler(async (_req, res) => {
  res.json({
    title: "Terms and Conditions",
    content:
      "By using Kalakriti, you agree to comply with these marketplace terms for purchases, vendor listings, and account usage.",
    sections: [
      {
        heading: "Account Responsibility",
        points: [
          "You are responsible for safeguarding your login credentials and OTP access.",
          "Provide accurate profile, shipping, and payment information at checkout.",
          "Any misuse, fraud, or policy abuse can result in suspension or termination.",
        ],
      },
      {
        heading: "Orders, Payments, and Returns",
        points: [
          "Orders are confirmed only after successful payment authorization.",
          "Coupons, loyalty redemption, and campaigns are subject to eligibility rules.",
          "Return and refund decisions depend on product category, condition, and seller policy.",
        ],
      },
      {
        heading: "Vendor Marketplace Rules",
        points: [
          "Vendors must list authentic handmade items and maintain truthful product details.",
          "Kalakriti may deduct commission from vendor sales as per configured rate.",
          "Featured listings and promotions may be paid services with defined validity periods.",
        ],
      },
      {
        heading: "Intellectual Property and Conduct",
        points: [
          "Logos, content, and designs on Kalakriti are protected by intellectual property laws.",
          "Users and vendors must not upload unlawful, abusive, or infringing content.",
          "We reserve the right to remove content that violates legal or policy obligations.",
        ],
      },
    ],
  });
});

const privacy = asyncHandler(async (_req, res) => {
  res.json({
    title: "Privacy Policy",
    content:
      "Kalakriti processes only the information needed to run accounts, complete orders, and provide customer support.",
    sections: [
      {
        heading: "What We Collect",
        points: [
          "Basic account data such as name, email, phone, and encrypted password.",
          "Order details, shipping addresses, and transactional metadata.",
          "Support requests and optional preferences like wishlist and loyalty usage.",
        ],
      },
      {
        heading: "How We Use Data",
        points: [
          "To authenticate users, prevent fraud, and secure platform access.",
          "To fulfill orders, track inventory, and manage vendor commissions.",
          "To improve products, recommendations, and seasonal campaign performance.",
        ],
      },
      {
        heading: "Cookies and Security",
        points: [
          "Cookies are used for secure sessions, CSRF protection, and user preferences.",
          "Security controls include JWT auth, password hashing, and request hardening.",
          "We do not sell personal data to third parties.",
        ],
      },
      {
        heading: "Your Rights",
        points: [
          "You may request profile updates, correction of inaccurate data, and account support.",
          "You can contact support for privacy questions and data handling clarifications.",
          "Policy updates will be published on this page with effective dates.",
        ],
      },
    ],
  });
});

module.exports = { terms, privacy };
