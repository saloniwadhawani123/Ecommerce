const env = require("./src/config/env");
const connectDB = require("./src/config/db");
const app = require("./src/app"); // ✅ IMPORTANT (no {})

const startServer = async () => {
  try {
    await connectDB();

    app.listen(env.port, () => {
      console.log(`🚀 Server running on port ${env.port}`);
    });

  } catch (error) {
    console.error("❌ Failed to start server:", error.message);
    process.exit(1);
  }
};

startServer();