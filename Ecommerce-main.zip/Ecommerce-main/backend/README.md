# Kalakriti Backend

Production-ready Express + MongoDB backend for Kalakriti e-commerce.

## Features
- JWT auth with role-based access (admin, user, vendor)
- 2FA OTP via email (json transport fallback in dev)
- XSS/NoSQL pollution/rate limiting/hpp/csrf protections
- Products, wishlist, cart, checkout, orders
- Loyalty points and referral rewards
- Vendor earnings and commission support
- Admin analytics, coupons, support query management

## Setup
1. Copy .env.example to .env
2. npm install
3. npm run seed
4. npm run dev

## MongoDB Network Resilience
- If Atlas blocks a new IP/network, configure both Atlas and local URIs in `MONGO_URIS`.
- The server will try URIs in order and automatically fall back when one is unreachable.
- Example:
	`MONGO_URIS=mongodb+srv://<atlas-uri>,mongodb://127.0.0.1:27017/kalakriti`
- Tune failover speed with `MONGO_CONNECT_TIMEOUT_MS` (default: 8000).

## Folder Structure
- src/config
- src/models
- src/controllers
- src/routes
- src/middlewares
- src/utils
