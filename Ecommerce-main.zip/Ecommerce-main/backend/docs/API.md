# Kalakriti API Documentation

## Base URL
- http://localhost:5000/api/v1

## Authentication
- JWT via cookie and bearer token
- Protected routes require Authorization: Bearer <token>
- CSRF token: first call GET /auth/csrf-token and send header x-csrf-token for non-GET requests

## Auth
- POST /auth/register
- POST /auth/login
- GET /auth/me
- POST /auth/logout
- POST /auth/2fa/request
- POST /auth/2fa/verify
- POST /auth/google (placeholder)

## Users
- PATCH /users/profile
- GET /users/wishlist
- POST /users/wishlist/:productId

## Products
- GET /products?search=&category=&minPrice=&maxPrice=&minRating=&sort=&page=&limit=
- GET /products/:slug
- POST /products (admin/vendor)
- PATCH /products/:id (admin/vendor)
- DELETE /products/:id (admin/vendor)
- POST /products/:id/reviews

## Cart
- GET /cart
- POST /cart { productId, quantity }
- PATCH /cart/:productId { quantity }
- DELETE /cart/:productId

## Orders
- POST /orders/checkout
- GET /orders/my-orders

## Vendor
- GET /vendors/dashboard
	- Returns vendor metrics, vendor products, and vendor-specific order/earnings breakdown

## Admin
- GET /admin/analytics
- GET /admin/users
- GET /admin/vendors
- GET /admin/products
- GET /admin/orders
- PATCH /admin/orders/:orderId/status
- PATCH /admin/products/:productId/priority
- PATCH /admin/vendors/:vendorId/commission
- PATCH /admin/users/:userId/loyalty
- PATCH /admin/users/:userId/referral-rewards
- POST /admin/coupons
- GET /admin/support-queries
- GET /admin/inventory-alerts

## Legal and Support
- GET /legal/terms
- GET /legal/privacy
- POST /support/contact

### Legal Payload Format
- title: String
- content: String
- sections: [{ heading: String, points: [String] }]
