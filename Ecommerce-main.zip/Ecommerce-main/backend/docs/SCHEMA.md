# Kalakriti Database Schema

## User
- name: String (required)
- email: String (required, unique)
- password: String (required, hashed with bcrypt)
- role: enum (admin, user, vendor)
- twoFactorEnabled: Boolean
- wishlist: [ProductId]
- cart: [{ product: ProductId, quantity: Number }]
- loyaltyPoints: Number
- referralCode: String (unique)
- referredBy: UserId
- referralRewards: Number
- addresses: [{ line1, line2, city, state, postalCode, country }]
- vendorProfile: { storeName, bio, commissionRate, earnings, totalSales }
- timestamps

## OTP
- user: UserId
- email: String
- otp: String
- purpose: enum (login2fa, enable2fa, verifyEmail, resetPassword)
- expiresAt: Date (TTL index)
- timestamps

## Product
- title: String
- slug: String (unique)
- description: String
- price: Number
- discountPrice: Number
- category: enum (Jewellery, Home Decor, Paintings, Crafts, Textiles, Personalized Gifts)
- images: [String]
- stock: Number
- lowStockThreshold: Number
- isFeatured: Boolean
- promotedUntil: Date
- priority: Number
- popularity: Number
- averageRating: Number
- totalRatings: Number
- reviews: [{ user: UserId, rating, comment, timestamps }]
- isPlatformProduct: Boolean
- vendor: UserId
- timestamps

## Order
- user: UserId
- items: [{ product, titleSnapshot, price, quantity, vendor, commissionRate, commissionAmount, lineTotal }]
- shippingAddress: { line1, line2, city, state, postalCode, country }
- paymentMethod: enum (mock, razorpay)
- paymentStatus: enum (pending, paid, failed)
- orderStatus: enum (placed, processing, shipped, delivered, cancelled)
- subtotal, discount, shippingFee, loyaltyRedeemed, total: Number
- couponCode: String
- trackingType: enum (platform, vendor, mixed)
- timestamps

## Coupon
- code: String (unique)
- description: String
- type: enum (percent, fixed)
- value: Number
- minOrderValue: Number
- maxDiscount: Number
- usageLimit: Number
- usedCount: Number
- active: Boolean
- expiresAt: Date
- timestamps

## ContactQuery
- name, email, subject, message: String
- status: enum (open, in-progress, resolved)
- timestamps

## Revenue and Control Notes
- Direct sales use Product.isPlatformProduct=true
- Vendor sales use Product.isPlatformProduct=false with vendor reference
- Order items store commissionRate and commissionAmount for vendor transactions
- Featured listings use Product.isFeatured, Product.priority, and Product.promotedUntil
- Seasonal campaigns and discounts use Coupon
