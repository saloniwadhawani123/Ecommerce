# Kalakriti Frontend

React + Tailwind storefront and dashboards for Kalakriti.

## Features
- Premium handmade aesthetic UI with earthy tones
- Responsive product grid, filters, and search
- Wishlist and cart flow integrated with backend
- Auth pages with 2FA-compatible login flow
- Checkout and order history
- Vendor and admin dashboard views
- Contact and legal pages
- Dark mode, motion transitions, skeleton states, toast feedback

## Setup
1. Copy .env.example to .env
2. npm install
3. npm run dev

## Build
- npm run build
