import { useEffect, useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import "./App.css";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import CookieConsent from "./components/CookieConsent";
import ProtectedRoute from "./components/ProtectedRoute";
import { useAuth } from "./context/AuthContext";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import UserLoginPage from "./pages/UserLoginPage";
import VendorLoginPage from "./pages/VendorLoginPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProductPage from "./pages/ProductPage";
import WishlistPage from "./pages/WishlistPage";
import CartPage from "./pages/CartPage";
import CheckoutPage from "./pages/CheckoutPage";
import OrdersPage from "./pages/OrdersPage";
import ProfilePage from "./pages/ProfilePage";
import VendorDashboardPage from "./pages/VendorDashboardPage";
import AdminDashboardPage from "./pages/AdminDashboardPage";
import ContactPage from "./pages/ContactPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import NotFoundPage from "./pages/NotFoundPage";

function App() {
  const { user } = useAuth();
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("kalakriti_dark") === "true");

  const roleHome = user?.role === "admin"
    ? "/admin/dashboard"
    : user?.role === "vendor"
      ? "/vendor/dashboard"
      : "/";

  useEffect(() => {
    document.body.classList.toggle("dark", darkMode);
    localStorage.setItem("kalakriti_dark", String(darkMode));
  }, [darkMode]);

  return (
    <div className="min-h-screen">
      <Navbar darkMode={darkMode} onThemeToggle={() => setDarkMode((s) => !s)} />
      <main>
        <Routes>
          <Route path="/" element={user?.role === "admin" ? <Navigate to="/admin/dashboard" replace /> : user?.role === "vendor" ? <Navigate to="/vendor/dashboard" replace /> : <HomePage />} />
          <Route path="/login" element={user ? <Navigate to={roleHome} replace /> : <LoginPage />} />
          <Route path="/login/user" element={user ? <Navigate to={roleHome} replace /> : <UserLoginPage />} />
          <Route path="/login/vendor" element={user ? <Navigate to={roleHome} replace /> : <VendorLoginPage />} />
          <Route path="/login/admin" element={user ? <Navigate to={roleHome} replace /> : <AdminLoginPage />} />
          <Route path="/register" element={user ? <Navigate to={roleHome} replace /> : <RegisterPage />} />
          <Route path="/product/:slug" element={<ProductPage />} />
          <Route path="/wishlist" element={<ProtectedRoute><WishlistPage /></ProtectedRoute>} />
          <Route path="/cart" element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
          <Route path="/checkout" element={<ProtectedRoute><CheckoutPage /></ProtectedRoute>} />
          <Route path="/orders" element={<ProtectedRoute><OrdersPage /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          <Route path="/vendor/dashboard" element={<ProtectedRoute roles={["vendor"]}><VendorDashboardPage /></ProtectedRoute>} />
          <Route path="/admin/dashboard" element={<ProtectedRoute roles={["admin"]}><AdminDashboardPage /></ProtectedRoute>} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/legal/terms" element={<TermsPage />} />
          <Route path="/legal/privacy" element={<PrivacyPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieConsent />
      <Toaster position="top-right" />
    </div>
  );
}

export default App;
