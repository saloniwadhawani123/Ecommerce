import LoginPage from "./LoginPage";

const UserLoginPage = () => (
  <LoginPage
    expectedRole="user"
    title="Customer Login"
    subtitle="Access your cart, wishlist, loyalty points, and orders."
  />
);

export default UserLoginPage;
