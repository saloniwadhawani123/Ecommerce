import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";

const roleLabels = {
  user: "Customer",
  vendor: "Vendor",
  admin: "Admin",
};

const getRedirectForRole = (role) => {
  if (role === "admin") return "/admin/dashboard";
  if (role === "vendor") return "/vendor/dashboard";
  return "/";
};

const LoginPage = ({ expectedRole = "", title = "Welcome back", subtitle }) => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
    otp: "",
  });

  const [needsOtp, setNeedsOtp] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();

    try {
      const payload = {
        email: form.email,
        password: form.password,
        ...(expectedRole ? { role: expectedRole } : {}),
        ...(needsOtp && form.otp ? { otp: form.otp } : {}),
      };

      const result = await login(payload);

      if (result?.requires2FA) {
        setNeedsOtp(true);
        toast.success("OTP sent to your email");
        return;
      }

      const role = result?.user?.role;

      if (expectedRole && role !== expectedRole) {
        toast.error(`This page is for ${roleLabels[expectedRole]} login only`);
        return;
      }

      navigate(getRedirectForRole(role));
    } catch (error) {
      toast.error(error?.response?.data?.message || "Login failed");
    }
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-12">
      <div className="rounded-3xl border border-clay/20 bg-white/85 p-8 shadow-soft dark:border-zinc-700 dark:bg-zinc-900/80">
        <h1 className="font-serifDisplay text-4xl text-ink dark:text-white">
          {title}
        </h1>

        <p className="mt-2 text-sm text-ink/70 dark:text-zinc-300">
          {subtitle || "Sign in to continue your handcrafted journey."}
        </p>

        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          
          {/* EMAIL */}
          <input
            name="email"  // ✅ FIXED
            className="w-full rounded-xl border-clay/30 bg-white/80 px-4 py-2"
            placeholder="Email"
            type="email"
            value={form.email}
            onChange={(e) =>
              setForm({ ...form, email: e.target.value })
            }
            required
          />

          {/* PASSWORD */}
          <input
            name="password"  // ✅ FIXED
            className="w-full rounded-xl border-clay/30 bg-white/80 px-4 py-2"
            placeholder="Password"
            type="password"
            value={form.password}
            onChange={(e) =>
              setForm({ ...form, password: e.target.value })
            }
            required
          />

          {/* OTP */}
          {needsOtp && (
            <input
              name="otp"  // ✅ FIXED
              className="w-full rounded-xl border-clay/30 bg-white/80 px-4 py-2"
              placeholder="6-digit OTP"
              value={form.otp}
              onChange={(e) =>
                setForm({ ...form, otp: e.target.value })
              }
              required
            />
          )}

          {/* BUTTON */}
          <button className="w-full rounded-xl bg-clay px-4 py-3 font-semibold text-white">
            Login
          </button>
        </form>

        <p className="mt-4 text-sm text-ink/70 dark:text-zinc-300">
          New here?{" "}
          <Link to="/register" className="font-semibold text-clay">
            Create account
          </Link>
        </p>

        {!expectedRole && (
          <div className="mt-4 grid gap-2 text-xs text-ink/70 dark:text-zinc-300 sm:grid-cols-3">
            <Link
              className="rounded-lg bg-sand px-3 py-2 text-center font-semibold hover:bg-mist dark:bg-zinc-800"
              to="/login/user"
            >
              User Login
            </Link>
            <Link
              className="rounded-lg bg-sand px-3 py-2 text-center font-semibold hover:bg-mist dark:bg-zinc-800"
              to="/login/vendor"
            >
              Vendor Login
            </Link>
            <Link
              className="rounded-lg bg-sand px-3 py-2 text-center font-semibold hover:bg-mist dark:bg-zinc-800"
              to="/login/admin"
            >
              Admin Login
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginPage;