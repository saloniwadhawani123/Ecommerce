import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/client";
import { formatCurrency } from "../utils/format";

const CartPage = () => {
  const [cart, setCart] = useState([]);

  const loadCart = async () => {
    const { data } = await api.get("/cart");
    setCart(data.cart || []);
  };

  useEffect(() => {
    loadCart().catch(() => setCart([]));
  }, []);

  const updateQty = async (productId, quantity) => {
    await api.patch(`/cart/${productId}`, { quantity });
    await loadCart();
  };

  const removeItem = async (productId) => {
    await api.delete(`/cart/${productId}`);
    await loadCart();
  };

  const subtotal = useMemo(
    () =>
      cart.reduce((sum, item) => {
        const price = item.product?.discountPrice || item.product?.price || 0;
        return sum + price * item.quantity;
      }, 0),
    [cart]
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <h1 className="font-serifDisplay text-4xl">Shopping Cart</h1>
      <div className="mt-6 grid gap-6 md:grid-cols-[1fr_300px]">
        <div className="space-y-4">
          {cart.map((item) => (
            <div key={item.product?._id} className="flex flex-col gap-4 rounded-2xl border border-clay/20 bg-white/80 p-4 md:flex-row md:items-center dark:border-zinc-700 dark:bg-zinc-900/80">
              <img src={item.product?.images?.[0]} alt={item.product?.title} className="h-24 w-24 rounded-xl object-cover" />
              <div className="flex-1">
                <p className="font-semibold">{item.product?.title}</p>
                <p className="text-sm text-ink/70 dark:text-zinc-300">{formatCurrency(item.product?.discountPrice || item.product?.price)}</p>
              </div>
              <input
                type="number"
                min={1}
                value={item.quantity}
                onChange={(e) => updateQty(item.product?._id, Number(e.target.value))}
                className="w-20 rounded-lg"
              />
              <button onClick={() => removeItem(item.product?._id)} className="rounded-lg border border-clay/30 px-3 py-2 text-sm text-clay">Remove</button>
            </div>
          ))}
        </div>
        <aside className="h-fit rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <p className="text-sm text-ink/70 dark:text-zinc-300">Subtotal</p>
          <p className="text-2xl font-bold text-clay">{formatCurrency(subtotal)}</p>
          <Link to="/checkout" className="mt-4 inline-block w-full rounded-xl bg-clay px-4 py-3 text-center font-semibold text-white">Checkout</Link>
        </aside>
      </div>
    </div>
  );
};

export default CartPage;
