import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import toast from "react-hot-toast";
import api from "../api/client";
import { formatCurrency } from "../utils/format";

const ProductPage = () => {
  const { slug } = useParams();
  const [product, setProduct] = useState(null);
  const [review, setReview] = useState({ rating: 5, comment: "" });

  useEffect(() => {
    api
      .get(`/products/${slug}`)
      .then(({ data }) => setProduct(data.product))
      .catch(() => toast.error("Failed to load product"));
  }, [slug]);

  const addToCart = async () => {
    try {
      await api.post("/cart", { productId: product._id, quantity: 1 });
      toast.success("Added to cart");
    } catch {
      toast.error("Please login to continue");
    }
  };

  const submitReview = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/products/${product._id}/reviews`, review);
      toast.success("Review submitted");
      setReview({ rating: 5, comment: "" });
    } catch {
      toast.error("Unable to submit review");
    }
  };

  if (!product) return <div className="p-8 text-center">Loading product...</div>;

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 md:grid-cols-2 md:px-6">
      <img src={product.images?.[0]} alt={product.title} className="h-full max-h-[520px] w-full rounded-2xl object-cover shadow-soft" />
      <div>
        <p className="text-sm uppercase tracking-wide text-clay">{product.category}</p>
        <h1 className="mt-2 font-serifDisplay text-4xl text-ink dark:text-white">{product.title}</h1>
        <p className="mt-4 text-lg text-ink/80 dark:text-zinc-300">{product.description}</p>
        <p className="mt-5 text-3xl font-bold text-clay">{formatCurrency(product.discountPrice || product.price)}</p>
        <button onClick={addToCart} className="mt-6 rounded-xl bg-olive px-6 py-3 font-semibold text-white hover:bg-olive/90">Add to Cart</button>

        <div className="mt-10 rounded-2xl border border-clay/20 bg-white/70 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold">Write a review</h2>
          <form onSubmit={submitReview} className="mt-3 space-y-3">
            <select value={review.rating} onChange={(e) => setReview({ ...review, rating: Number(e.target.value) })} className="w-full rounded-lg">
              {[5, 4, 3, 2, 1].map((r) => (
                <option key={r} value={r}>{r} Stars</option>
              ))}
            </select>
            <textarea
              rows={3}
              className="w-full rounded-lg"
              placeholder="Share your experience"
              value={review.comment}
              onChange={(e) => setReview({ ...review, comment: e.target.value })}
            />
            <button className="rounded-lg bg-clay px-4 py-2 text-white">Submit Review</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;
