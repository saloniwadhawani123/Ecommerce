import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import api from "../api/client";
import ProductCard from "../components/ProductCard";
import SkeletonCard from "../components/SkeletonCard";

const categories = ["", "Jewellery", "Home Decor", "Paintings", "Crafts", "Textiles", "Personalized Gifts"];

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");
  const [sort, setSort] = useState("popularity");
  const [wishlist, setWishlist] = useState([]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/products", {
        params: {
          search: query,
          category: category || undefined,
          sort,
          limit: 18,
        },
      });
      setProducts(data.products || []);
    } catch (error) {
      const status = error?.response?.status;
      const message = error?.response?.data?.message;
      toast.error(message || (status ? `Failed to load products (${status})` : "Failed to load products"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [category, sort]);

  const onSearch = (event) => {
    event.preventDefault();
    fetchProducts();
  };

  const handleWishlist = async (productId) => {
    try {
      await api.post(`/users/wishlist/${productId}`);
      setWishlist((prev) => (prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]));
      toast.success("Wishlist updated");
    } catch {
      toast.error("Please login to update wishlist");
    }
  };

  const handleAddCart = async (productId) => {
    try {
      await api.post("/cart", { productId, quantity: 1 });
      toast.success("Added to cart");
    } catch {
      toast.error("Please login to add items");
    }
  };

  const featured = useMemo(() => products.filter((item) => item.isFeatured).slice(0, 3), [products]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-6">
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl border border-clay/25 bg-white/80 p-8 shadow-soft dark:border-zinc-700 dark:bg-zinc-900/70 md:p-12"
      >
        <div className="pointer-events-none absolute -right-14 -top-16 h-64 w-64 rounded-full bg-clay/25 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-16 -left-16 h-56 w-56 rounded-full bg-olive/20 blur-3xl" />
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Handmade Elegance</p>
        <h1 className="mt-3 max-w-3xl font-serifDisplay text-5xl font-semibold leading-tight text-ink dark:text-white md:text-7xl">
          Discover artisan-crafted treasures for soulful spaces.
        </h1>
        <p className="mt-4 max-w-2xl text-ink/70 dark:text-zinc-300">
          Kalakriti blends direct craftsmanship and curated vendor collections with premium design, loyalty rewards, and secure shopping.
        </p>
        <form onSubmit={onSearch} className="mt-6 flex flex-col gap-3 md:flex-row">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search handmade products..."
            className="w-full rounded-xl border-clay/30 bg-white text-ink placeholder:text-ink/45 px-4 py-3 dark:bg-zinc-900 dark:text-zinc-100 dark:placeholder:text-zinc-400"
          />
          <button className="rounded-xl bg-clay px-6 py-3 font-semibold text-white hover:bg-clay/90">Search</button>
        </form>
      </motion.section>

      {featured.length ? (
        <section className="mt-10">
          <h2 className="font-serifDisplay text-3xl text-ink dark:text-white">Featured Showcase</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {featured.map((item) => (
              <div key={item._id} className="rounded-2xl border border-clay/20 bg-white/85 p-4 dark:border-zinc-700 dark:bg-zinc-900/80">
                <p className="text-xs uppercase tracking-wide text-clay">Featured Listing</p>
                <h3 className="mt-2 text-lg font-semibold">{item.title}</h3>
                <p className="mt-1 text-sm text-ink/70 dark:text-zinc-300">{item.category}</p>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="mt-10">
        <div className="flex flex-col gap-3 rounded-2xl border border-clay/20 bg-white/70 p-4 dark:border-zinc-700 dark:bg-zinc-900/70 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2">
            {categories.map((item) => (
              <button
                key={item || "all"}
                onClick={() => setCategory(item)}
                className={`rounded-full px-4 py-2 text-sm font-semibold ${
                  category === item
                    ? "bg-clay text-white"
                    : "bg-sand text-ink hover:bg-mist dark:bg-zinc-800 dark:text-zinc-200"
                }`}
              >
                {item || "All"}
              </button>
            ))}
          </div>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-lg border-clay/30 bg-white/80 text-sm dark:bg-zinc-800"
          >
            <option value="popularity">Popularity</option>
            <option value="rating">Top Rated</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="newest">Newest</option>
          </select>
        </div>

        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {loading
            ? Array.from({ length: 6 }).map((_, idx) => <SkeletonCard key={idx} />)
            : products.map((product) => (
                <ProductCard
                  key={product._id}
                  product={product}
                  wished={wishlist.includes(product._id)}
                  onWishlist={handleWishlist}
                  onAddToCart={handleAddCart}
                />
              ))}
        </div>
        {!loading && products.length === 0 ? (
          <p className="mt-6 rounded-xl border border-clay/20 bg-white/80 px-4 py-3 text-sm text-ink/75 dark:border-zinc-700 dark:bg-zinc-900/80 dark:text-zinc-300">
            No products found right now. Try changing filters/search, or check backend connectivity.
          </p>
        ) : null}
      </section>
    </div>
  );
};

export default HomePage;
