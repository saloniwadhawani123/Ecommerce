import LoginPage from "./LoginPage";

const AdminLoginPage = () => (
  <LoginPage
    expectedRole="admin"
    title="Admin Login"
    subtitle="Control products, vendors, orders, coupons, referrals, and loyalty."
  />
);

export default AdminLoginPage;
