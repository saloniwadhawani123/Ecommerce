import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import api from "../api/client";

const emptyProduct = {
  title: "",
  description: "",
  price: "",
  category: "Jewellery",
  stock: "",
  images: "",
};

const VendorDashboardPage = () => {
  const [data, setData] = useState(null);
  const [form, setForm] = useState(emptyProduct);
  const [editingId, setEditingId] = useState("");

  const loadDashboard = async () => {
    const res = await api.get("/vendors/dashboard");
    setData(res.data);
  };

  useEffect(() => {
    loadDashboard().catch(() => toast.error("Vendor access required"));
  }, []);

  const createProduct = async (e) => {
    e.preventDefault();
    const payload = {
      title: form.title,
      description: form.description,
      price: Number(form.price),
      category: form.category,
      stock: Number(form.stock),
      images: form.images ? [form.images] : [],
    };

    if (editingId) {
      await api.patch(`/products/${editingId}`, payload);
      toast.success("Product updated");
    } else {
      await api.post("/products", payload);
      toast.success("Product created");
    }

    setForm(emptyProduct);
    setEditingId("");
    await loadDashboard();
  };

  const startEdit = (product) => {
    setEditingId(product._id);
    setForm({
      title: product.title,
      description: product.description,
      price: product.price,
      category: product.category,
      stock: product.stock,
      images: product.images?.[0] || "",
    });
  };

  const deleteProduct = async (productId) => {
    try {
      await api.delete(`/products/${productId}`);
      toast.success("Product deleted");
      await loadDashboard();
    } catch {
      toast.error("Could not delete product");
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <h1 className="font-serifDisplay text-4xl">Vendor Dashboard</h1>
      <div className="mt-3 rounded-xl border border-clay/25 bg-clay/10 px-4 py-3 text-sm text-ink dark:border-zinc-700 dark:bg-zinc-900/70 dark:text-zinc-200">
        <p className="font-semibold text-clay">Signed in as Vendor</p>
        <p className="mt-1 text-ink/75 dark:text-zinc-300">Upload products, monitor approval status, manage listings, and track your earnings.</p>
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-4">
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Products: {data?.metrics?.totalProducts || 0}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Orders: {data?.metrics?.orders || 0}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Earnings: {Math.round(data?.metrics?.earnings || 0)}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Sales: {Math.round(data?.metrics?.totalSales || 0)}</div>
      </div>

      <form onSubmit={createProduct} className="mt-8 rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
        <h2 className="text-xl font-semibold">{editingId ? "Edit Product" : "Add Product"}</h2>
        <p className="mt-1 text-sm text-ink/70 dark:text-zinc-300">Submitted or edited products go to admin review before public listing.</p>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <input className="rounded-lg" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <select className="rounded-lg" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {["Jewellery", "Home Decor", "Paintings", "Crafts", "Textiles", "Personalized Gifts"].map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
          <input className="rounded-lg" type="number" placeholder="Price" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required />
          <input className="rounded-lg" type="number" placeholder="Stock" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} required />
        </div>
        <textarea className="mt-3 w-full rounded-lg" rows={3} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required />
        <input className="mt-3 w-full rounded-lg" placeholder="Image URL" value={form.images} onChange={(e) => setForm({ ...form, images: e.target.value })} />

        <div className="mt-4 rounded-xl border border-clay/20 bg-sand/70 p-4 dark:border-zinc-700 dark:bg-zinc-950/40">
          <p className="text-xs font-semibold uppercase tracking-wide text-clay">Live Preview</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-[120px_1fr]">
            <img
              src={form.images || "https://images.unsplash.com/photo-1514996937319-344454492b37"}
              alt="Preview"
              className="h-24 w-full rounded-lg object-cover"
            />
            <div>
              <p className="font-semibold text-ink dark:text-zinc-100">{form.title || "Product title"}</p>
              <p className="text-xs text-ink/70 dark:text-zinc-300">{form.category}</p>
              <p className="mt-1 text-sm text-ink/80 dark:text-zinc-200">{form.description || "Product description preview"}</p>
              <p className="mt-1 text-sm font-semibold text-clay">{form.price ? `INR ${Number(form.price).toLocaleString("en-IN")}` : "INR 0"}</p>
              <span className="mt-1 inline-block rounded-full bg-amber-100 px-2 py-1 text-[11px] font-semibold text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">Pending approval</span>
            </div>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button className="rounded-lg bg-clay px-4 py-2 font-semibold text-white">{editingId ? "Update" : "Create"}</button>
          {editingId ? (
            <button type="button" className="rounded-lg border border-clay/30 px-4 py-2 text-sm font-semibold text-clay" onClick={() => {
              setForm(emptyProduct);
              setEditingId("");
            }}>
              Cancel
            </button>
          ) : null}
        </div>
      </form>

      <section className="mt-8 rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
        <h2 className="text-xl font-semibold">My Products</h2>
        <p className="mt-1 text-sm text-ink/70 dark:text-zinc-300">New uploads stay pending until an admin approves them.</p>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          {(data?.products || []).map((product) => (
            <div key={product._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
              <div className="flex items-start justify-between gap-2">
                <p className="font-semibold">{product.title}</p>
                <span className={`rounded-full px-2 py-1 text-[11px] font-semibold ${product.approvalStatus === "approved" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300" : product.approvalStatus === "rejected" ? "bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300" : "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300"}`}>
                  {product.approvalStatus || "approved"}
                </span>
              </div>
              <p className="text-sm text-ink/70 dark:text-zinc-300">Stock: {product.stock} | Price: {Math.round(product.price)}</p>
              {product.approvalStatus === "rejected" && product.rejectionReason ? (
                <p className="mt-1 text-xs text-rose-700 dark:text-rose-300">Reason: {product.rejectionReason}</p>
              ) : null}
              <div className="mt-2 flex gap-2">
                <button onClick={() => startEdit(product)} className="rounded-lg bg-sand px-3 py-1 text-xs font-semibold dark:bg-zinc-800">Edit</button>
                <button onClick={() => deleteProduct(product._id)} className="rounded-lg bg-rose-100 px-3 py-1 text-xs font-semibold text-rose-700 dark:bg-rose-950/40 dark:text-rose-300">Delete</button>
              </div>
            </div>
          ))}
          {!data?.products?.length ? <p className="text-sm text-ink/70 dark:text-zinc-300">No products listed yet.</p> : null}
        </div>
      </section>

      <section className="mt-8 rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
        <h2 className="text-xl font-semibold">Vendor Orders and Earnings</h2>
        <div className="mt-3 space-y-3">
          {(data?.orders || []).map((order) => (
            <div key={order._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
              <p className="text-xs text-ink/60 dark:text-zinc-300">Order #{order._id.slice(-8)} | {new Date(order.createdAt).toLocaleDateString()}</p>
              <p className="mt-1 text-sm">Customer: {order.customer?.name || "Guest"}</p>
              <p className="text-sm">Status: {order.orderStatus} | Payment: {order.paymentStatus}</p>
              <p className="text-sm">Gross: {Math.round(order.gross)} | Commission: {Math.round(order.commission)} | Net: {Math.round(order.net)}</p>
            </div>
          ))}
          {!data?.orders?.length ? <p className="text-sm text-ink/70 dark:text-zinc-300">No vendor orders yet.</p> : null}
        </div>
      </section>
    </div>
  );
};

export default VendorDashboardPage;
