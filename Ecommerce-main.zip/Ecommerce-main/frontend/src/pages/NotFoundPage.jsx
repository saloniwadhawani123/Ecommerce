import { Link } from "react-router-dom";

const NotFoundPage = () => (
  <div className="mx-auto max-w-xl px-4 py-20 text-center">
    <h1 className="font-serifDisplay text-5xl">404</h1>
    <p className="mt-3 text-ink/70 dark:text-zinc-300">The page you requested could not be found.</p>
    <Link to="/" className="mt-6 inline-block rounded-lg bg-clay px-4 py-2 font-semibold text-white">Go Home</Link>
  </div>
);

export default NotFoundPage;
