import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import api from "../api/client";
import { useAuth } from "../context/AuthContext";

const ProfilePage = () => {
  const { user, fetchMe } = useAuth();
  const [form, setForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
  });
  const [dailyReward, setDailyReward] = useState(null);

  const loadDailyRewardStatus = async () => {
    if (user?.role !== "user") return;
    try {
      const { data } = await api.get("/users/daily-reward/status");
      setDailyReward(data);
    } catch {
      setDailyReward(null);
    }
  };

  useEffect(() => {
    setForm({ name: user?.name || "", phone: user?.phone || "" });
    loadDailyRewardStatus();
  }, [user?.name, user?.phone, user?.role]);

  const updateProfile = async (e) => {
    e.preventDefault();
    await api.patch("/users/profile", form);
    await fetchMe();
    toast.success("Profile updated");
  };

  const enable2FA = async () => {
    await api.post("/auth/2fa/request");
    const otp = window.prompt("Enter OTP sent to your email");
    if (!otp) return;
    await api.post("/auth/2fa/verify", { otp });
    toast.success("2FA enabled");
    await fetchMe();
  };

  const claimDailyReward = async () => {
    try {
      const { data } = await api.post("/users/daily-reward/claim");
      toast.success(`Claimed ${data.rewardPoints} points. Streak: ${data.streak} days`);
      await fetchMe();
      await loadDailyRewardStatus();
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not claim reward");
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="font-serifDisplay text-4xl">My Profile</h1>
      <div className="mt-3 rounded-xl border border-clay/25 bg-clay/10 px-4 py-3 text-sm text-ink dark:border-zinc-700 dark:bg-zinc-900/70 dark:text-zinc-200">
        <p className="font-semibold text-clay">Signed in as Customer</p>
        <p className="mt-1 text-ink/75 dark:text-zinc-300">Track orders, manage rewards, update profile details, and control account security.</p>
      </div>
      <div className="mt-6 rounded-2xl border border-clay/20 bg-white/80 p-6 dark:border-zinc-700 dark:bg-zinc-900/80">
        <p className="text-sm text-ink/70 dark:text-zinc-300">Role: {user?.role}</p>
        <p className="text-sm text-ink/70 dark:text-zinc-300">Loyalty points: {user?.loyaltyPoints || 0}</p>
        <p className="text-sm text-ink/70 dark:text-zinc-300">Referral code: {user?.referralCode || "-"}</p>

        {user?.role === "user" ? (
          <div className="mt-4 rounded-xl border border-clay/25 bg-sand/70 p-4 dark:border-zinc-700 dark:bg-zinc-950/40">
            <p className="text-xs font-semibold uppercase tracking-wide text-clay">Daily Artisan Reward</p>
            <p className="mt-1 text-sm text-ink/80 dark:text-zinc-200">
              Claim points once per day and build your streak for extra rewards.
            </p>
            <p className="mt-2 text-sm text-ink/70 dark:text-zinc-300">Current streak: {dailyReward?.streak || 0} days</p>
            <button
              onClick={claimDailyReward}
              disabled={!dailyReward?.eligible}
              className={`mt-3 rounded-lg px-4 py-2 text-sm font-semibold ${
                dailyReward?.eligible
                  ? "bg-clay text-white hover:bg-clay/90"
                  : "cursor-not-allowed bg-zinc-300 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
              }`}
            >
              {dailyReward?.eligible ? "Claim Today\'s Reward" : "Already Claimed Today"}
            </button>
          </div>
        ) : null}

        <form onSubmit={updateProfile} className="mt-5 space-y-3">
          <input className="w-full rounded-xl" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Name" required />
          <input className="w-full rounded-xl" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Phone" />
          <button className="rounded-xl bg-clay px-5 py-2 font-semibold text-white">Save</button>
        </form>

        <button onClick={enable2FA} className="mt-4 rounded-xl border border-clay/40 px-5 py-2 font-semibold text-clay">
          Enable 2FA via Email OTP
        </button>
      </div>
    </div>
  );
};

export default ProfilePage;
