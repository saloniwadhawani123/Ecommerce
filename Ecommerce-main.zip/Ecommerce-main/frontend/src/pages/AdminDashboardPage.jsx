import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import api from "../api/client";

const AdminDashboardPage = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [analytics, setAnalytics] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [users, setUsers] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [products, setProducts] = useState([]);
  const [pendingProducts, setPendingProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [queries, setQueries] = useState([]);
  const [coupon, setCoupon] = useState({
    code: "",
    description: "",
    type: "percent",
    value: 10,
    minOrderValue: 500,
    usageLimit: 100,
    maxDiscount: 500,
  });

  const loadDashboard = async () => {
    const [a, inv, us, vs, ps, pending, os, sq] = await Promise.all([
      api.get("/admin/analytics"),
      api.get("/admin/inventory-alerts"),
      api.get("/admin/users"),
      api.get("/admin/vendors"),
      api.get("/admin/products"),
      api.get("/admin/products/pending"),
      api.get("/admin/orders"),
      api.get("/admin/support-queries"),
    ]);

    setAnalytics(a.data.analytics);
    setAlerts(inv.data.lowStock || []);
    setUsers(us.data.users || []);
    setVendors(vs.data.vendors || []);
    setProducts(ps.data.products || []);
    setPendingProducts(pending.data.pendingProducts || []);
    setOrders(os.data.orders || []);
    setQueries(sq.data.queries || []);
  };

  useEffect(() => {
    (async () => {
      try {
        await loadDashboard();
      } catch {
        toast.error("Admin access required");
      }
    })();
  }, []);

  const updateOrderStatus = async (orderId, orderStatus) => {
    try {
      await api.patch(`/admin/orders/${orderId}/status`, { orderStatus });
      toast.success("Order status updated");
      await loadDashboard();
    } catch {
      toast.error("Failed to update order status");
    }
  };

  const setProductPriority = async (productId, priority, isFeatured) => {
    try {
      await api.patch(`/admin/products/${productId}/priority`, { priority, isFeatured });
      toast.success("Product priority updated");
      await loadDashboard();
    } catch {
      toast.error("Failed to update product priority");
    }
  };

  const reviewProduct = async (productId, status) => {
    try {
      await api.patch(`/admin/products/${productId}/review`, { status });
      toast.success(`Product ${status}`);
      await loadDashboard();
    } catch {
      toast.error("Failed to update approval");
    }
  };

  const setVendorCommission = async (vendorId, commissionRate) => {
    try {
      await api.patch(`/admin/vendors/${vendorId}/commission`, { commissionRate });
      toast.success("Vendor commission updated");
      await loadDashboard();
    } catch {
      toast.error("Failed to update vendor commission");
    }
  };

  const updateLoyalty = async (userId, loyaltyPoints) => {
    try {
      await api.patch(`/admin/users/${userId}/loyalty`, { loyaltyPoints });
      toast.success("Loyalty points updated");
      await loadDashboard();
    } catch {
      toast.error("Failed to update loyalty points");
    }
  };

  const updateReferral = async (userId, referralRewards) => {
    try {
      await api.patch(`/admin/users/${userId}/referral-rewards`, { referralRewards });
      toast.success("Referral rewards updated");
      await loadDashboard();
    } catch {
      toast.error("Failed to update referral rewards");
    }
  };

  const createCoupon = async (event) => {
    event.preventDefault();
    try {
      await api.post("/admin/coupons", {
        ...coupon,
        code: coupon.code.toUpperCase(),
        value: Number(coupon.value),
        minOrderValue: Number(coupon.minOrderValue),
        usageLimit: Number(coupon.usageLimit),
        maxDiscount: Number(coupon.maxDiscount),
      });
      toast.success("Coupon created");
      setCoupon({
        code: "",
        description: "",
        type: "percent",
        value: 10,
        minOrderValue: 500,
        usageLimit: 100,
        maxDiscount: 500,
      });
    } catch {
      toast.error("Failed to create coupon");
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-6">
      <h1 className="font-serifDisplay text-4xl">Admin Command Center</h1>
      <div className="mt-3 rounded-xl border border-clay/25 bg-clay/10 px-4 py-3 text-sm text-ink dark:border-zinc-700 dark:bg-zinc-900/70 dark:text-zinc-200">
        <p className="font-semibold text-clay">Signed in as Administrator</p>
        <p className="mt-1 text-ink/75 dark:text-zinc-300">You can manage approvals, orders, products, vendors, users, campaigns, and support.</p>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {[
          { key: "overview", label: "Overview" },
          { key: "approvals", label: "Approvals" },
          { key: "orders", label: "Orders" },
          { key: "products", label: "Products" },
          { key: "vendors", label: "Vendors" },
          { key: "users", label: "Users" },
          { key: "support", label: "Support" },
          { key: "campaigns", label: "Campaigns" },
        ].map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={`rounded-full px-4 py-2 text-sm font-semibold ${
              activeTab === tab.key
                ? "bg-clay text-white"
                : "bg-white/80 text-ink hover:bg-mist dark:bg-zinc-900/80 dark:text-zinc-200"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-5">
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Users: {analytics?.users || 0}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Vendors: {analytics?.vendors || 0}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Products: {analytics?.products || 0}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Orders: {analytics?.totalOrders || 0}</div>
        <div className="rounded-xl bg-white/80 p-4 dark:bg-zinc-900/80">Revenue: {Math.round(analytics?.grossRevenue || 0)}</div>
      </div>

      {activeTab === "overview" ? (
      <section className="mt-8 rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
        <h2 className="text-xl font-semibold text-clay">Low Stock Alerts</h2>
        <div className="mt-3 space-y-3">
          {alerts.map((item) => (
            <div key={item._id} className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-700 dark:bg-amber-950/30 dark:text-amber-200">
              {item.title}: {item.stock} left ({item.isPlatformProduct ? "Platform" : "Vendor"})
            </div>
          ))}
          {!alerts.length ? <p className="text-sm text-ink/70 dark:text-zinc-300">No low-stock products.</p> : null}
        </div>
      </section>
      ) : null}

      {activeTab === "approvals" || activeTab === "orders" || activeTab === "campaigns" ? (
      <section className="mt-8 grid gap-5 lg:grid-cols-2">
        {activeTab === "approvals" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Pending Vendor Approvals</h2>
          <p className="mt-1 text-sm text-ink/70 dark:text-zinc-300">Vendor uploads remain hidden from the public until approved.</p>
          <div className="mt-3 max-h-80 space-y-3 overflow-auto pr-1">
            {pendingProducts.map((product) => (
              <div key={product._id} className="rounded-lg border border-amber-300 bg-amber-50 p-3 dark:border-amber-700 dark:bg-amber-950/20">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-ink dark:text-zinc-100">{product.title}</p>
                    <p className="text-xs text-ink/70 dark:text-zinc-300">{product.vendor?.name || "Vendor"} | {product.category}</p>
                    <p className="mt-1 text-xs text-ink/60 dark:text-zinc-400">{product.description}</p>
                  </div>
                  <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-amber-700 dark:bg-zinc-900">Pending</span>
                </div>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => reviewProduct(product._id, "approved")} className="rounded-lg bg-olive px-3 py-2 text-xs font-semibold text-white">Approve</button>
                  <button onClick={() => reviewProduct(product._id, "rejected")} className="rounded-lg bg-rose-600 px-3 py-2 text-xs font-semibold text-white">Reject</button>
                </div>
              </div>
            ))}
            {!pendingProducts.length ? <p className="text-sm text-ink/70 dark:text-zinc-300">No pending items.</p> : null}
          </div>
        </div>
        ) : null}

        {activeTab === "orders" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Orders Management</h2>
          <div className="mt-3 max-h-80 space-y-3 overflow-auto pr-1">
            {orders.map((order) => (
              <div key={order._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
                <p className="text-xs text-ink/60 dark:text-zinc-300">#{order._id.slice(-8)} | {order.user?.email || "Customer"}</p>
                <p className="mt-1 text-sm">Total: {Math.round(order.total)} | {order.paymentStatus}</p>
                <div className="mt-2 flex gap-2">
                  <select
                    className="rounded-lg text-sm"
                    defaultValue={order.orderStatus}
                    onChange={(e) => updateOrderStatus(order._id, e.target.value)}
                  >
                    {[
                      "placed",
                      "processing",
                      "shipped",
                      "delivered",
                      "cancelled",
                    ].map((status) => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>
        ) : null}

        {activeTab === "campaigns" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Create Campaign Coupon</h2>
          <form onSubmit={createCoupon} className="mt-3 space-y-3">
            <input className="w-full rounded-lg" placeholder="Code" value={coupon.code} onChange={(e) => setCoupon({ ...coupon, code: e.target.value })} required />
            <input className="w-full rounded-lg" placeholder="Description" value={coupon.description} onChange={(e) => setCoupon({ ...coupon, description: e.target.value })} required />
            <div className="grid gap-3 sm:grid-cols-2">
              <select className="rounded-lg" value={coupon.type} onChange={(e) => setCoupon({ ...coupon, type: e.target.value })}>
                <option value="percent">Percent</option>
                <option value="fixed">Fixed</option>
              </select>
              <input className="rounded-lg" type="number" min={1} value={coupon.value} onChange={(e) => setCoupon({ ...coupon, value: e.target.value })} required />
              <input className="rounded-lg" type="number" min={0} value={coupon.minOrderValue} onChange={(e) => setCoupon({ ...coupon, minOrderValue: e.target.value })} required />
              <input className="rounded-lg" type="number" min={1} value={coupon.usageLimit} onChange={(e) => setCoupon({ ...coupon, usageLimit: e.target.value })} required />
            </div>
            <button className="rounded-lg bg-clay px-4 py-2 text-sm font-semibold text-white">Save Coupon</button>
          </form>
        </div>
        ) : null}
      </section>
      ) : null}

      {activeTab === "vendors" || activeTab === "users" ? (
      <section className="mt-8 grid gap-5 lg:grid-cols-2">
        {activeTab === "vendors" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Vendor Commission Control</h2>
          <div className="mt-3 max-h-80 space-y-3 overflow-auto pr-1">
            {vendors.map((vendor) => (
              <div key={vendor._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
                <p className="text-sm font-semibold">{vendor.name}</p>
                <p className="text-xs text-ink/60 dark:text-zinc-300">{vendor.email}</p>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    className="w-24 rounded-lg text-sm"
                    type="number"
                    min={0}
                    max={100}
                    defaultValue={vendor.vendorProfile?.commissionRate || 12}
                    onBlur={(e) => setVendorCommission(vendor._id, e.target.value)}
                  />
                  <span className="text-xs">Commission %</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        ) : null}

        {activeTab === "users" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Loyalty and Referral Control</h2>
          <div className="mt-3 max-h-80 space-y-3 overflow-auto pr-1">
            {users.map((item) => (
              <div key={item._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
                <p className="text-sm font-semibold">{item.name}</p>
                <p className="text-xs text-ink/60 dark:text-zinc-300">{item.email}</p>
                <div className="mt-2 grid gap-2 sm:grid-cols-2">
                  <input
                    className="rounded-lg text-sm"
                    type="number"
                    min={0}
                    defaultValue={item.loyaltyPoints || 0}
                    onBlur={(e) => updateLoyalty(item._id, e.target.value)}
                  />
                  <input
                    className="rounded-lg text-sm"
                    type="number"
                    min={0}
                    defaultValue={item.referralRewards || 0}
                    onBlur={(e) => updateReferral(item._id, e.target.value)}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
        ) : null}
      </section>
      ) : null}

      {activeTab === "products" || activeTab === "support" ? (
      <section className="mt-8 grid gap-5 lg:grid-cols-2">
        {activeTab === "products" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Featured Product Priority</h2>
          <div className="mt-3 max-h-80 space-y-3 overflow-auto pr-1">
            {products.map((product) => (
              <div key={product._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
                <p className="text-sm font-semibold">{product.title}</p>
                <p className="text-xs text-ink/60 dark:text-zinc-300">{product.isPlatformProduct ? "Platform" : "Vendor"}</p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <input
                    className="w-24 rounded-lg text-sm"
                    type="number"
                    defaultValue={product.priority || 0}
                    onBlur={(e) => setProductPriority(product._id, e.target.value, product.isFeatured)}
                  />
                  <button
                    onClick={() => setProductPriority(product._id, product.priority || 0, !product.isFeatured)}
                    className="rounded-lg bg-sand px-3 py-1 text-xs font-semibold dark:bg-zinc-800"
                  >
                    {product.isFeatured ? "Unfeature" : "Feature"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        ) : null}

        {activeTab === "support" ? (
        <div className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
          <h2 className="text-xl font-semibold text-clay">Customer Support Inbox</h2>
          <div className="mt-3 max-h-80 space-y-3 overflow-auto pr-1">
            {queries.map((query) => (
              <div key={query._id} className="rounded-lg border border-clay/20 p-3 dark:border-zinc-700">
                <p className="text-sm font-semibold">{query.subject}</p>
                <p className="text-xs text-ink/60 dark:text-zinc-300">{query.name} | {query.email}</p>
                <p className="mt-2 text-sm text-ink/80 dark:text-zinc-200">{query.message}</p>
              </div>
            ))}
            {!queries.length ? <p className="text-sm text-ink/70 dark:text-zinc-300">No support queries yet.</p> : null}
          </div>
        </div>
        ) : null}
      </section>
      ) : null}
    </div>
  );
};

export default AdminDashboardPage;
