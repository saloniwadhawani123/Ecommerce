import { useState } from "react";
import toast from "react-hot-toast";
import api from "../api/client";

const ContactPage = () => {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [chatOpen, setChatOpen] = useState(false);

  const quickReplies = [
    "Where is my order?",
    "How do I return a product?",
    "How vendor commission works?",
  ];

  const onSubmit = async (e) => {
    e.preventDefault();
    await api.post("/support/contact", form);
    toast.success("Support request submitted");
    setForm({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="relative mx-auto max-w-3xl px-4 py-10">
      <h1 className="font-serifDisplay text-4xl">Contact Us</h1>
      <p className="mt-2 text-sm text-ink/70 dark:text-zinc-300">Need help with an order, product, or vendor? We are here for you.</p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4 rounded-2xl border border-clay/20 bg-white/80 p-6 dark:border-zinc-700 dark:bg-zinc-900/80">
        <input className="w-full rounded-xl" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input className="w-full rounded-xl" type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <input className="w-full rounded-xl" placeholder="Subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} required />
        <textarea className="w-full rounded-xl" rows={5} placeholder="Message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required />
        <button className="rounded-xl bg-clay px-5 py-3 font-semibold text-white">Submit Query</button>
      </form>

      <button
        onClick={() => setChatOpen((state) => !state)}
        className="fixed bottom-6 right-6 rounded-full bg-clay px-4 py-3 text-sm font-semibold text-white shadow-soft"
      >
        {chatOpen ? "Close Support" : "Live Support"}
      </button>

      {chatOpen ? (
        <div className="fixed bottom-24 right-6 w-[320px] rounded-2xl border border-clay/30 bg-white p-4 shadow-soft dark:border-zinc-700 dark:bg-zinc-900">
          <p className="text-sm font-semibold text-clay">Kalakriti Support Assistant</p>
          <p className="mt-1 text-xs text-ink/70 dark:text-zinc-300">Quick help for common questions. For complete support, use the form above.</p>
          <div className="mt-3 space-y-2">
            {quickReplies.map((reply) => (
              <button
                key={reply}
                onClick={() => toast(reply)}
                className="w-full rounded-lg bg-sand px-3 py-2 text-left text-xs font-semibold hover:bg-mist dark:bg-zinc-800"
              >
                {reply}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default ContactPage;
