import { useState } from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import api from "../api/client";

const CheckoutPage = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    line1: "",
    city: "",
    state: "",
    postalCode: "",
    country: "India",
    paymentMethod: "upi",
    upiId: "",
    cardNumber: "",
    cardName: "",
    cardExpiry: "",
    cardCvv: "",
    couponCode: "",
    redeemPoints: 0,
  });

  const onSubmit = async (e) => {
    e.preventDefault();

    if (form.paymentMethod === "upi" && !form.upiId.trim()) {
      toast.error("Please enter a valid UPI ID");
      return;
    }

    if (form.paymentMethod === "card" && !form.cardNumber.trim()) {
      toast.error("Please enter card details");
      return;
    }

    try {
      await api.post("/orders/checkout", {
        shippingAddress: {
          line1: form.line1,
          city: form.city,
          state: form.state,
          postalCode: form.postalCode,
          country: form.country,
        },
        paymentMethod: form.paymentMethod,
        paymentDetails:
          form.paymentMethod === "upi"
            ? { upiId: form.upiId.trim() }
            : form.paymentMethod === "card"
              ? {
                  cardNumber: form.cardNumber,
                  cardName: form.cardName,
                  cardExpiry: form.cardExpiry,
                  cardCvv: form.cardCvv,
                }
              : undefined,
        couponCode: form.couponCode || undefined,
        redeemPoints: Number(form.redeemPoints || 0),
      });
      toast.success("Order placed");
      navigate("/orders");
    } catch (error) {
      toast.error(error?.response?.data?.message || "Checkout failed");
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="font-serifDisplay text-4xl">Checkout</h1>
      <form onSubmit={onSubmit} className="mt-6 space-y-4 rounded-3xl border border-clay/20 bg-white/80 p-6 dark:border-zinc-700 dark:bg-zinc-900/80">
        <input className="w-full rounded-xl" placeholder="Address line" value={form.line1} onChange={(e) => setForm({ ...form, line1: e.target.value })} required />
        <div className="grid gap-4 md:grid-cols-3">
          <input className="rounded-xl" placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} required />
          <input className="rounded-xl" placeholder="State" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} required />
          <input className="rounded-xl" placeholder="Postal code" value={form.postalCode} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} required />
        </div>
        <div className="space-y-2">
          <p className="text-sm font-semibold text-ink dark:text-zinc-100">Payment Method</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {[
              { value: "upi", label: "UPI" },
              { value: "card", label: "Card" },
              { value: "cod", label: "Cash on Delivery" },
              { value: "razorpay", label: "Razorpay" },
            ].map((method) => (
              <button
                key={method.value}
                type="button"
                onClick={() => setForm({ ...form, paymentMethod: method.value })}
                className={`rounded-xl border px-3 py-2 text-left text-sm font-semibold ${
                  form.paymentMethod === method.value
                    ? "border-clay bg-clay/10 text-clay"
                    : "border-clay/25 bg-white/70 text-ink dark:border-zinc-700 dark:bg-zinc-900"
                }`}
              >
                {method.label}
              </button>
            ))}
          </div>
        </div>

        {form.paymentMethod === "upi" ? (
          <input
            className="w-full rounded-xl"
            placeholder="UPI ID (example@upi)"
            value={form.upiId}
            onChange={(e) => setForm({ ...form, upiId: e.target.value })}
            required
          />
        ) : null}

        {form.paymentMethod === "card" ? (
          <div className="grid gap-3 md:grid-cols-2">
            <input className="rounded-xl md:col-span-2" placeholder="Card number" value={form.cardNumber} onChange={(e) => setForm({ ...form, cardNumber: e.target.value })} required />
            <input className="rounded-xl" placeholder="Card holder name" value={form.cardName} onChange={(e) => setForm({ ...form, cardName: e.target.value })} required />
            <div className="grid grid-cols-2 gap-3">
              <input className="rounded-xl" placeholder="MM/YY" value={form.cardExpiry} onChange={(e) => setForm({ ...form, cardExpiry: e.target.value })} required />
              <input className="rounded-xl" placeholder="CVV" value={form.cardCvv} onChange={(e) => setForm({ ...form, cardCvv: e.target.value })} required />
            </div>
          </div>
        ) : null}

        {form.paymentMethod === "cod" ? (
          <p className="rounded-xl border border-clay/25 bg-sand px-3 py-2 text-sm text-ink dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200">
            Cash on Delivery selected. Payment will be collected at delivery.
          </p>
        ) : null}

        {form.paymentMethod === "razorpay" ? (
          <p className="rounded-xl border border-clay/25 bg-sand px-3 py-2 text-sm text-ink dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200">
            Razorpay mode selected. Integration token flow can be plugged in next.
          </p>
        ) : null}
        <div className="grid gap-4 md:grid-cols-2">
          <input className="rounded-xl" placeholder="Coupon code" value={form.couponCode} onChange={(e) => setForm({ ...form, couponCode: e.target.value })} />
          <input className="rounded-xl" type="number" min={0} placeholder="Redeem loyalty points" value={form.redeemPoints} onChange={(e) => setForm({ ...form, redeemPoints: e.target.value })} />
        </div>
        <button className="w-full rounded-xl bg-clay px-5 py-3 font-semibold text-white">Place Order</button>
      </form>
    </div>
  );
};

export default CheckoutPage;
