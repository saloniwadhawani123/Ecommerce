import { useEffect, useState } from "react";
import api from "../api/client";
import ProductCard from "../components/ProductCard";

const WishlistPage = () => {
  const [wishlist, setWishlist] = useState([]);

  const loadWishlist = async () => {
    const { data } = await api.get("/users/wishlist");
    setWishlist(data.wishlist || []);
  };

  useEffect(() => {
    loadWishlist().catch(() => setWishlist([]));
  }, []);

  const handleWishlist = async (productId) => {
    await api.post(`/users/wishlist/${productId}`);
    await loadWishlist();
  };

  const addToCart = async (productId) => {
    await api.post("/cart", { productId, quantity: 1 });
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-6">
      <h1 className="font-serifDisplay text-4xl">My Wishlist</h1>
      <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {wishlist.map((product) => (
          <ProductCard
            key={product._id}
            product={product}
            wished
            onWishlist={handleWishlist}
            onAddToCart={addToCart}
          />
        ))}
      </div>
    </div>
  );
};

export default WishlistPage;
