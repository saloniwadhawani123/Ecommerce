import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import api from "../api/client";

const fallbackPrivacy = {
  title: "Privacy Policy",
  content:
    "Kalakriti processes only the information needed to run accounts, complete orders, and provide customer support.",
  sections: [
    {
      heading: "What We Collect",
      points: [
        "Basic account data such as name, email, phone, and encrypted password.",
        "Order details, shipping addresses, and transactional metadata.",
      ],
    },
  ],
};

const PrivacyPage = () => {
  const [data, setData] = useState(fallbackPrivacy);

  useEffect(() => {
    api
      .get("/legal/privacy")
      .then((res) => setData(res.data))
      .catch(() => {
        toast.error("Unable to load Privacy Policy right now");
        setData(fallbackPrivacy);
      });
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="font-serifDisplay text-4xl">{data.title}</h1>
      <div className="mt-5 rounded-2xl border border-clay/20 bg-white/80 p-6 leading-8 dark:border-zinc-700 dark:bg-zinc-900/80">
        <p>{data.content}</p>
        <div className="mt-6 space-y-5">
          {data.sections?.map((section) => (
            <div key={section.heading}>
              <h2 className="text-lg font-semibold text-clay">{section.heading}</h2>
              <ul className="mt-2 list-disc space-y-2 pl-5 text-ink/85 dark:text-zinc-200">
                {section.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PrivacyPage;
