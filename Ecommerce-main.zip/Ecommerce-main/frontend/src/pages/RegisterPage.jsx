import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";

const RegisterPage = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "user",
    referralCode: "",
    storeName: "",
    bio: "",
  });

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      await register({
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role,
        referralCode: form.referralCode || undefined,
        vendorProfile:
          form.role === "vendor"
            ? {
                storeName: form.storeName,
                bio: form.bio,
              }
            : undefined,
      });
      navigate("/");
    } catch (error) {
      toast.error(error?.response?.data?.message || "Registration failed");
    }
  };

  return (
    <div className="mx-auto max-w-xl px-4 py-12">
      <div className="rounded-3xl border border-clay/20 bg-white/85 p-8 shadow-soft dark:border-zinc-700 dark:bg-zinc-900/80">
        <h1 className="font-serifDisplay text-4xl text-ink dark:text-white">Create your Kalakriti account</h1>
        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          <input className="w-full rounded-xl" placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <input className="w-full rounded-xl" placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
          <input
            className="w-full rounded-xl"
            placeholder="Strong password"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
          <input className="w-full rounded-xl" placeholder="Referral code (optional)" value={form.referralCode} onChange={(e) => setForm({ ...form, referralCode: e.target.value })} />
          <select className="w-full rounded-xl" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
            <option value="user">Customer</option>
            <option value="vendor">Vendor / Artisan</option>
          </select>

          {form.role === "vendor" ? (
            <>
              <input className="w-full rounded-xl" placeholder="Store name" value={form.storeName} onChange={(e) => setForm({ ...form, storeName: e.target.value })} required />
              <textarea className="w-full rounded-xl" rows={3} placeholder="Store bio" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
            </>
          ) : null}

          <button className="w-full rounded-xl bg-clay px-4 py-3 font-semibold text-white">Create Account</button>
        </form>
        <p className="mt-4 text-sm text-ink/70 dark:text-zinc-300">
          Already a member? <Link to="/login" className="font-semibold text-clay">Login</Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;
