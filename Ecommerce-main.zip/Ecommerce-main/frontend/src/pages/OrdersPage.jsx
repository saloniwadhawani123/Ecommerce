import { useEffect, useState } from "react";
import api from "../api/client";
import { formatCurrency } from "../utils/format";

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    api.get("/orders/my-orders").then(({ data }) => setOrders(data.orders || []));
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <h1 className="font-serifDisplay text-4xl">Order History</h1>
      <div className="mt-6 space-y-4">
        {orders.map((order) => (
          <div key={order._id} className="rounded-2xl border border-clay/20 bg-white/80 p-5 dark:border-zinc-700 dark:bg-zinc-900/80">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm text-ink/70 dark:text-zinc-300">Order #{order._id.slice(-8)}</p>
              <p className="rounded-full bg-mist px-3 py-1 text-xs font-semibold text-ink dark:bg-zinc-800 dark:text-zinc-200">{order.orderStatus}</p>
            </div>
            <p className="mt-3 text-lg font-semibold text-clay">{formatCurrency(order.total)}</p>
            <p className="text-sm text-ink/70 dark:text-zinc-300">Items: {order.items.length} | Tracking: {order.trackingType}</p>
            <p className="text-sm text-ink/70 dark:text-zinc-300">Payment: {order.paymentMethod} ({order.paymentStatus})</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrdersPage;
