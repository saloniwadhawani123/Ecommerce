import LoginPage from "./LoginPage";

const VendorLoginPage = () => (
  <LoginPage
    expectedRole="vendor"
    title="Vendor Login"
    subtitle="Manage artisan products, orders, commissions, and earnings."
  />
);

export default VendorLoginPage;
