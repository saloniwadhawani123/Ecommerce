import { Link, NavLink, useNavigate } from "react-router-dom";
import { ShoppingCart, Heart, User2 } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import { useAuth } from "../context/AuthContext";

const linkClass = ({ isActive }) =>
  `text-sm font-semibold transition ${isActive ? "text-clay" : "text-ink/80 hover:text-clay dark:text-zinc-200"}`;

const Navbar = ({ darkMode, onThemeToggle }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const dashboardPath = user?.role === "admin"
    ? "/admin/dashboard"
    : user?.role === "vendor"
      ? "/vendor/dashboard"
      : "/profile";

  const roleLabel = user?.role === "admin"
    ? "Admin"
    : user?.role === "vendor"
      ? "Vendor"
      : user?.role === "user"
        ? "Customer"
        : "";

  return (
    <header className="sticky top-0 z-40 border-b border-clay/15 bg-sand/80 backdrop-blur dark:border-zinc-700 dark:bg-zinc-950/75">
      <nav className="mx-auto max-w-7xl px-4 py-3 md:px-6">
        <div className="flex items-center justify-between">
        <Link to="/" className="font-serifDisplay text-3xl font-semibold text-clay">Kalakriti</Link>

        <div className="hidden items-center gap-5 md:flex">
          <NavLink to="/" className={linkClass}>Home</NavLink>
          <NavLink to="/contact" className={linkClass}>Contact</NavLink>
          <NavLink to="/legal/terms" className={linkClass}>Terms</NavLink>
          <NavLink to="/legal/privacy" className={linkClass}>Privacy</NavLink>
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle darkMode={darkMode} onToggle={onThemeToggle} />
          {user?.role === "user" || !user ? (
            <>
              <Link to="/wishlist" className="rounded-full p-2 text-clay hover:bg-white/80 dark:text-amber-300"><Heart size={18} /></Link>
              <Link to="/cart" className="rounded-full p-2 text-clay hover:bg-white/80 dark:text-amber-300"><ShoppingCart size={18} /></Link>
            </>
          ) : null}

          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate(dashboardPath)}
                className="rounded-lg bg-clay px-3 py-2 text-sm font-semibold text-white"
              >
                {roleLabel} Dashboard
              </button>

              <button
                onClick={() => navigate("/profile")}
                className="inline-flex items-center gap-1 rounded-lg bg-white/80 px-3 py-2 text-sm font-semibold text-ink dark:bg-zinc-800 dark:text-zinc-200"
              >
                <User2 size={16} />
                {user.name?.split(" ")[0]}
              </button>
              <button
                onClick={logout}
                className="rounded-lg border border-clay/30 px-3 py-2 text-sm font-semibold text-clay"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link to="/login" className="rounded-lg bg-clay px-4 py-2 text-sm font-semibold text-white hover:bg-clay/90">
              Login
            </Link>
          )}
        </div>
        </div>

        <div className="mt-3 flex items-center gap-4 md:hidden">
          <NavLink to="/" className={linkClass}>Home</NavLink>
          <NavLink to="/contact" className={linkClass}>Contact</NavLink>
          <NavLink to="/legal/terms" className={linkClass}>Terms</NavLink>
          <NavLink to="/legal/privacy" className={linkClass}>Privacy</NavLink>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
