import { Moon, Sun } from "lucide-react";

const ThemeToggle = ({ darkMode, onToggle }) => (
  <button
    onClick={onToggle}
    className="rounded-full border border-amber-700/30 bg-white/70 p-2 text-amber-800 backdrop-blur hover:bg-white dark:border-zinc-600 dark:bg-zinc-900/70 dark:text-amber-300"
    aria-label="Toggle dark mode"
  >
    {darkMode ? <Sun size={18} /> : <Moon size={18} />}
  </button>
);

export default ThemeToggle;
