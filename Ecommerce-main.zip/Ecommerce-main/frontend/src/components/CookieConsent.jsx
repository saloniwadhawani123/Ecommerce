import { useEffect, useState } from "react";

const CookieConsent = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem("kalakriti_cookie_ok");
    setVisible(!accepted);
  }, []);

  const accept = () => {
    localStorage.setItem("kalakriti_cookie_ok", "true");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-4 left-1/2 z-50 w-[92%] max-w-2xl -translate-x-1/2 rounded-2xl border border-clay/30 bg-white/95 p-4 shadow-soft backdrop-blur dark:border-zinc-700 dark:bg-zinc-900/95">
      <p className="text-sm text-ink/80 dark:text-zinc-200">
        We use cookies to improve your shopping experience, personalize content, and keep your account secure.
      </p>
      <div className="mt-3 flex justify-end">
        <button
          onClick={accept}
          className="rounded-lg bg-clay px-4 py-2 text-sm font-semibold text-white hover:bg-clay/90"
        >
          Accept Cookies
        </button>
      </div>
    </div>
  );
};

export default CookieConsent;
