import { Heart, Star, ShoppingBag } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { formatCurrency, shorten } from "../utils/format";

const ProductCard = ({ product, onWishlist, onAddToCart, wished }) => {
  const image = product.images?.[0] || "https://images.unsplash.com/photo-1514996937319-344454492b37";

  return (
    <motion.article
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="group relative overflow-hidden rounded-2xl border border-clay/20 bg-white/90 p-3 shadow-soft transition dark:border-zinc-700 dark:bg-zinc-900/80"
    >
      <button
        onClick={() => onWishlist(product._id)}
        className="absolute right-5 top-5 z-10 rounded-full bg-white/95 p-2 text-clay shadow dark:bg-zinc-800"
      >
        <Heart size={16} className={wished ? "fill-clay text-clay" : ""} />
      </button>

      <div className="absolute left-5 top-5 z-10 flex flex-wrap gap-2">
        {product.isFeatured ? (
          <span className="rounded-full bg-clay px-2 py-1 text-[11px] font-semibold text-white">Featured</span>
        ) : null}
        {product.approvalStatus && product.approvalStatus !== "approved" ? (
          <span
            className={`rounded-full px-2 py-1 text-[11px] font-semibold ${
              product.approvalStatus === "pending"
                ? "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300"
                : "bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300"
            }`}
          >
            {product.approvalStatus}
          </span>
        ) : null}
      </div>

      <Link to={`/product/${product.slug}`}>
        <div className="overflow-hidden rounded-xl">
          <img
            src={image}
            alt={product.title}
            className="h-44 w-full object-cover transition duration-500 group-hover:scale-110"
          />
        </div>
      </Link>

      <div className="mt-3 space-y-2 px-1">
        <div className="flex items-center justify-between text-xs text-ink/70 dark:text-zinc-300">
          <span>{product.category}</span>
          <span className="inline-flex items-center gap-1">
            <Star size={14} className="text-amber-500" />
            {(product.averageRating || 4.5).toFixed(1)}
          </span>
        </div>

        <Link to={`/product/${product.slug}`} className="block text-lg font-semibold leading-snug text-ink dark:text-white">
          {shorten(product.title, 48)}
        </Link>

        <div className="flex items-baseline gap-2">
          <p className="font-bold text-clay">{formatCurrency(product.discountPrice || product.price)}</p>
          {product.discountPrice ? (
            <p className="text-sm text-ink/50 line-through dark:text-zinc-400">{formatCurrency(product.price)}</p>
          ) : null}
        </div>

        <button
          onClick={() => onAddToCart(product._id)}
          className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-olive px-3 py-2 font-semibold text-white hover:bg-olive/90"
        >
          <ShoppingBag size={16} />
          Add to Cart
        </button>
      </div>
    </motion.article>
  );
};

export default ProductCard;
