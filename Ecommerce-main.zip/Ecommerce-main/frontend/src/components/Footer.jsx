import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="mt-16 border-t border-clay/20 bg-white/60 py-8 dark:border-zinc-700 dark:bg-zinc-900/60">
    <div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 px-4 text-sm text-ink/70 md:flex-row md:px-6 dark:text-zinc-300">
      <div>
        <p>Kalakriti. Handmade stories crafted for modern homes.</p>
        <div className="mt-2 flex items-center gap-4">
          <Link to="/legal/terms" className="font-semibold text-clay hover:underline">Terms</Link>
          <Link to="/legal/privacy" className="font-semibold text-clay hover:underline">Privacy</Link>
        </div>
      </div>
      <p>Revenue streams: direct sales, vendor commission, featured listings, campaigns.</p>
    </div>
  </footer>
);

export default Footer;
