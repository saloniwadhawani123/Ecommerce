const SkeletonCard = () => (
  <div className="animate-pulse rounded-2xl border border-clay/15 bg-white/80 p-4 dark:border-zinc-700 dark:bg-zinc-900/70">
    <div className="h-40 rounded-xl bg-mist/70 dark:bg-zinc-700" />
    <div className="mt-4 h-4 w-3/4 rounded bg-mist/70 dark:bg-zinc-700" />
    <div className="mt-2 h-3 w-1/2 rounded bg-mist/70 dark:bg-zinc-700" />
    <div className="mt-5 h-9 rounded-lg bg-mist/70 dark:bg-zinc-700" />
  </div>
);

export default SkeletonCard;
