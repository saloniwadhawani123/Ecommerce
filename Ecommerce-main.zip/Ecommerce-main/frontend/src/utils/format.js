export const formatCurrency = (value = 0) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);

export const shorten = (value = "", max = 100) =>
  value.length > max ? `${value.slice(0, max)}...` : value;
