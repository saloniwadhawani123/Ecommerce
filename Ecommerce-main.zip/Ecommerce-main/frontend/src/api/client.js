import axios from "axios";

const normalizeApiBase = (rawBaseUrl) => {
  const host = window.location.hostname;
  const isLoopbackHost = ["localhost", "127.0.0.1", "0.0.0.0"].includes(host);
  const isIpv4Host = /^(\d{1,3}\.){3}\d{1,3}$/.test(host);
  const isRenderHost = /\.onrender\.com$/i.test(host);

  let renderFallbackBase = "/api/v1";
  if (isRenderHost && host.includes("frontend")) {
    const backendHost = host.replace("frontend", "backend");
    renderFallbackBase = `https://${backendHost}/api/v1`;
  }

  // In local development, prefer an explicit backend URL even when the app is opened via LAN IP.
  const fallbackBase =
    isLoopbackHost || isIpv4Host
      ? `http://${host === "0.0.0.0" ? "localhost" : host}:5000/api/v1`
      : renderFallbackBase;
  if (!rawBaseUrl) return fallbackBase;

  const cleaned = String(rawBaseUrl).trim().replace(/\/+$/, "");
  if (!cleaned) return fallbackBase;

  const apiV1Match = cleaned.match(/^(.*?\/api\/v1)(?:\/.*)?$/i);
  if (apiV1Match) return apiV1Match[1];

  const apiMatch = cleaned.match(/^(.*?\/api)(?:\/.*)?$/i);
  if (apiMatch) return `${apiMatch[1]}/v1`;

  return `${cleaned}/api/v1`;
};

const api = axios.create({
  baseURL: normalizeApiBase(import.meta.env.VITE_API_URL),
  withCredentials: true,
});

const getCookieValue = (name) => {
  const match = document.cookie
    .split(";")
    .map((cookie) => cookie.trim())
    .find((cookie) => cookie.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.split("=")[1]) : "";
};

api.interceptors.request.use((config) => {
  const method = (config.method || "get").toLowerCase();
  if (!["get", "head", "options"].includes(method)) {
    const csrfToken = getCookieValue("csrfToken");
    if (csrfToken) {
      config.headers["x-csrf-token"] = csrfToken;
    }
  }
  return config;
});

export const bootstrapCsrf = async () => {
  await api.get("/auth/csrf-token");
};

export default api;