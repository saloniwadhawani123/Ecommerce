from flask import Flask, render_template, request, redirect, url_for
from database import get_db_connection, init_db

app = Flask(__name__)

# =========================================================
# INITIALIZE DATABASE
# =========================================================

init_db()


# =========================================================
# HOME PAGE
# =========================================================

@app.route("/")
def home():
    return render_template("index.html")


# =========================================================
# MOOD TRACKER
# =========================================================

@app.route("/mood", methods=["GET", "POST"])
def mood():

    # Save mood
    if request.method == "POST":

        selected_mood = request.form.get("mood")
        note = request.form.get("note", "").strip()

        if selected_mood:

            connection = get_db_connection()

            connection.execute(
                """
                INSERT INTO moods (mood, note)
                VALUES (?, ?)
                """,
                (selected_mood, note)
            )

            connection.commit()
            connection.close()

        return redirect(url_for("mood"))

    # Display mood history
    connection = get_db_connection()

    moods = connection.execute(
        """
        SELECT id, mood, note, created_at
        FROM moods
        ORDER BY created_at DESC
        """
    ).fetchall()

    connection.close()

    return render_template(
        "mood.html",
        moods=moods
    )


# =========================================================
# MEDITATION
# =========================================================

@app.route("/meditation")
def meditation():

    return render_template("meditation.html")


# =========================================================
# MIND EXERCISES
# =========================================================

@app.route("/exercises")
def exercises():

    return render_template("exercises.html")


# =========================================================
# DAILY JOURNAL
# =========================================================

@app.route("/journal", methods=["GET", "POST"])
def journal():

    # Save journal entry
    if request.method == "POST":

        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()

        if title and content:

            connection = get_db_connection()

            connection.execute(
                """
                INSERT INTO journal (title, content)
                VALUES (?, ?)
                """,
                (title, content)
            )

            connection.commit()
            connection.close()

        return redirect(url_for("journal"))

    # Display previous journal entries
    connection = get_db_connection()

    entries = connection.execute(
        """
        SELECT id, title, content, created_at
        FROM journal
        ORDER BY created_at DESC
        """
    ).fetchall()

    connection.close()

    return render_template(
        "journal.html",
        entries=entries
    )


# =========================================================
# NEED TO TALK / CHATBOT
# =========================================================

@app.route("/chatbot")
def chatbot():

    return render_template("chatbot.html")


# =========================================================
# MOTIVATIONAL QUOTES
# =========================================================

@app.route("/quotes")
def quotes():

    return render_template("quotes.html")


# =========================================================
# THERAPIST / SUPPORT CONTACTS
# =========================================================

@app.route("/therapists")
def therapists():

    return render_template("therapists.html")


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":
    app.run(debug=True)