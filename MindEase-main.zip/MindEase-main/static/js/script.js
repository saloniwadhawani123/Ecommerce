/* =========================================================
   MINDEASE - MAIN JAVASCRIPT
   ========================================================= */


/* =========================================================
   1. GENERAL PAGE LOADING
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    console.log("MindEase JavaScript loaded successfully 🌸");


    /* -----------------------------------------------------
       Enter key support for chatbot
    ----------------------------------------------------- */

    const chatInput = document.getElementById("chatInput");

    if (chatInput) {

        chatInput.addEventListener("keydown", function (event) {

            if (event.key === "Enter") {

                event.preventDefault();

                if (typeof sendMessage === "function") {
                    sendMessage();
                }

            }

        });

    }


    /* -----------------------------------------------------
       Load journal entries
    ----------------------------------------------------- */

    loadJournalEntries();


    /* -----------------------------------------------------
       Dark mode
    ----------------------------------------------------- */

    const darkMode =
        localStorage.getItem("mindEaseDarkMode");

    if (darkMode === "true") {

        document.body.classList.add("dark-mode");

    }

});


/* =========================================================
   2. MOOD TRACKER
   ========================================================= */

function selectMood(mood) {

    const moodInput =
        document.getElementById("selectedMood");

    if (moodInput) {

        moodInput.value = mood;

    }


    document
        .querySelectorAll(".mood-option")
        .forEach(function (option) {

            option.classList.remove("selected");

        });


    /* Use the clicked mood option */

    if (typeof event !== "undefined" && event.currentTarget) {

        event.currentTarget.classList.add("selected");

    }

}


/* =========================================================
   3. MEDITATION TIMER
   ========================================================= */

let meditationTimer = null;
let meditationSeconds = 0;
let meditationRunning = false;


/* START NEW MEDITATION */

function startMeditation(minutes) {

    // Stop any existing timer
    if (meditationTimer !== null) {

        clearInterval(meditationTimer);

        meditationTimer = null;

    }


    // Set selected time
    meditationSeconds = minutes * 60;

    meditationRunning = true;


    // Show timer immediately
    updateMeditationTimer();


    // Start countdown
    meditationTimer = setInterval(function () {

        meditationSeconds--;

        updateMeditationTimer();


        // Timer finished
        if (meditationSeconds <= 0) {

            clearInterval(meditationTimer);

            meditationTimer = null;

            meditationRunning = false;

            meditationSeconds = 0;

            updateMeditationTimer();

            meditationFinished();

        }

    }, 1000);

}


/* PAUSE */

function pauseMeditation() {

    if (meditationTimer !== null) {

        clearInterval(meditationTimer);

        meditationTimer = null;

    }

    meditationRunning = false;

}


/* RESUME */

function resumeMeditation() {

    // Nothing to resume
    if (meditationSeconds <= 0) {

        alert("Please choose a meditation time first. 🌸");

        return;

    }


    // Already running
    if (meditationRunning) {
        return;
    }


    meditationRunning = true;


    meditationTimer = setInterval(function () {

        meditationSeconds--;

        updateMeditationTimer();


        if (meditationSeconds <= 0) {

            clearInterval(meditationTimer);

            meditationTimer = null;

            meditationRunning = false;

            meditationSeconds = 0;

            updateMeditationTimer();

            meditationFinished();

        }

    }, 1000);

}


/* RESET */

function resetMeditation() {

    if (meditationTimer !== null) {

        clearInterval(meditationTimer);

    }


    meditationTimer = null;

    meditationSeconds = 0;

    meditationRunning = false;


    updateMeditationTimer();

}


/* UPDATE TIMER DISPLAY */

function updateMeditationTimer() {

    const timer =
        document.getElementById("meditationTimer");


    if (!timer) {
        return;
    }


    const minutes =
        Math.floor(meditationSeconds / 60);


    const seconds =
        meditationSeconds % 60;


    timer.textContent =
        String(minutes).padStart(2, "0")
        + ":"
        + String(seconds).padStart(2, "0");

}


/* MEDITATION COMPLETE */

function meditationFinished() {

    const timer =
        document.getElementById("meditationTimer");


    if (timer) {

        timer.textContent = "00:00";

    }


    alert(
        "Your meditation session is complete. 🌸 Take a moment to notice how you feel."
    );

}

/* =========================================================
   4. BREATHING EXERCISE
   ========================================================= */

let breathingInterval = null;

let breathingRunning = false;


function startBreathing() {

    if (breathingRunning) {
        return;
    }


    const circle =
        document.getElementById("breathingCircle");

    const instruction =
        document.getElementById("breathingInstruction");


    if (!circle || !instruction) {
        return;
    }


    breathingRunning = true;


    let phase = 0;


    const breathingPhases = [

        {
            text: "Breathe In 🌿",
            duration: 4000
        },

        {
            text: "Hold 💜",
            duration: 4000
        },

        {
            text: "Breathe Out 🌸",
            duration: 6000
        },

        {
            text: "Rest",
            duration: 2000
        }

    ];


    function nextPhase() {

        if (!breathingRunning) {
            return;
        }


        const current =
            breathingPhases[phase];


        instruction.textContent =
            current.text;


        if (current.text === "Breathe In 🌿") {

            circle.classList.remove("breathing-out");

            circle.classList.add("breathing-in");

        }


        if (current.text === "Breathe Out 🌸") {

            circle.classList.remove("breathing-in");

            circle.classList.add("breathing-out");

        }


        if (
            current.text === "Hold 💜" ||
            current.text === "Rest"
        ) {

            circle.classList.remove("breathing-in");
            circle.classList.remove("breathing-out");

        }


        breathingInterval = setTimeout(function () {

            phase++;

            if (phase >= breathingPhases.length) {

                phase = 0;

            }


            nextPhase();

        }, current.duration);

    }


    nextPhase();

}


function stopBreathing() {

    breathingRunning = false;


    if (breathingInterval) {

        clearTimeout(breathingInterval);

        breathingInterval = null;

    }


    const circle =
        document.getElementById("breathingCircle");

    const instruction =
        document.getElementById("breathingInstruction");


    if (circle) {

        circle.classList.remove("breathing-in");
        circle.classList.remove("breathing-out");

    }


    if (instruction) {

        instruction.textContent =
            "Press Start to begin";

    }

}


/* =========================================================
   5. EXERCISES
   ========================================================= */

function completeExercise(button) {

    if (!button) {
        return;
    }


    button.textContent =
        "✓ Completed";

    button.disabled = true;

    button.classList.add("completed");


    const message =
        document.getElementById("exerciseMessage");


    if (message) {

        message.textContent =
            "Great job! You completed the exercise. 🌸";

    }

}


/* =========================================================
   6. EXERCISE CATEGORY FILTER
   ========================================================= */

function filterExercises(category, button) {

    const exercises =
        document.querySelectorAll(".exercise-card");


    const buttons =
        document.querySelectorAll(".exercise-filter");


    buttons.forEach(function (btn) {

        btn.classList.remove("active");

    });


    if (button) {

        button.classList.add("active");

    }


    exercises.forEach(function (exercise) {

        const exerciseCategory =
            exercise.dataset.category;


        if (
            category === "all" ||
            exerciseCategory === category
        ) {

            exercise.style.display = "block";

        }

        else {

            exercise.style.display = "none";

        }

    });

}


/* =========================================================
   7. JOURNAL
   ========================================================= */

function saveJournal() {

    const journal =
        document.getElementById("journalEntry");


    if (!journal) {
        return;
    }


    const text =
        journal.value.trim();


    if (text === "") {

        alert(
            "Please write something before saving. 🌸"
        );

        return;

    }


    const date =
        new Date().toLocaleString();


    const existing =
        JSON.parse(
            localStorage.getItem(
                "mindEaseJournal"
            ) || "[]"
        );


    existing.push({

        text: text,

        date: date

    });


    localStorage.setItem(
        "mindEaseJournal",
        JSON.stringify(existing)
    );


    alert(
        "Your journal entry has been saved. 💜"
    );


    journal.value = "";


    loadJournalEntries();

}


/* =========================================================
   8. LOAD JOURNAL ENTRIES
   ========================================================= */

function loadJournalEntries() {

    const container =
        document.getElementById("journalEntries");


    if (!container) {
        return;
    }


    const entries =
        JSON.parse(
            localStorage.getItem(
                "mindEaseJournal"
            ) || "[]"
        );


    container.innerHTML = "";


    if (entries.length === 0) {

        container.innerHTML = `
            <div class="empty-journal">

                <div>📖</div>

                <p>
                    No journal entries yet. 🌸
                </p>

                <p>
                    Start writing about your day.
                </p>

            </div>
        `;

        return;

    }


    entries
        .slice()
        .reverse()
        .forEach(function (entry) {

            const div =
                document.createElement("div");


            div.className =
                "journal-entry";


            div.innerHTML = `

                <div class="entry-header">

                    <h3>
                        My Journal
                    </h3>

                    <small>
                        ${escapeHTML(entry.date)}
                    </small>

                </div>

                <div class="entry-content">
                    ${escapeHTML(entry.text)}
                </div>

            `;


            container.appendChild(div);

        });

}


/* =========================================================
   9. CLEAR JOURNAL
   ========================================================= */

function clearJournal() {

    const confirmDelete =
        confirm(
            "Are you sure you want to delete all journal entries?"
        );


    if (!confirmDelete) {
        return;
    }


    localStorage.removeItem(
        "mindEaseJournal"
    );


    loadJournalEntries();

}


/* =========================================================
   10. MOTIVATIONAL QUOTES
   ========================================================= */


/*
   Quotes are divided into categories.
*/

const mindEaseQuotes = {

    low: [

        "It is okay to have bad days. They do not define your whole life. 🌸",

        "You don't have to be strong every second. Give yourself permission to rest. 💜",

        "This difficult moment will pass. Be gentle with yourself. 🌿",

        "You are allowed to take things one day at a time.",

        "Even when you cannot see the light, it does not mean the light is gone."

    ],


    breakup: [

        "Healing does not mean forgetting. It means remembering without breaking. 💜",

        "Sometimes letting go is the beginning of finding yourself again.",

        "Your heart will heal. Give it the time it deserves. 🌸",

        "You lost a relationship, not your worth.",

        "One day, this chapter will simply become part of your story."

    ],


    alone: [

        "Being alone does not mean you are unloved. 💜",

        "You are worthy of connection, care and understanding.",

        "Even on lonely days, you are never without your own strength.",

        "Your presence matters more than you realize. 🌸",

        "It is okay to reach out when you need someone."

    ],


    anxiety: [

        "Take a slow breath. You only need to handle this moment. 🌿",

        "You are safe in this moment. Breathe and take it one step at a time.",

        "Not every thought deserves your attention.",

        "You don't have to solve tomorrow today.",

        "Breathe in peace. Breathe out tension. 💜"

    ],


    stress: [

        "You don't have to do everything at once.",

        "Rest is not laziness. Rest is necessary. 🌸",

        "Take a break. Your mind deserves it.",

        "One task at a time. One breath at a time.",

        "You are doing enough. Give yourself some credit. 💜"

    ],


    motivation: [

        "Believe you can, and you are already halfway there. 💪",

        "Small steps still move you forward.",

        "Your future self will thank you for not giving up today.",

        "Progress is progress, no matter how small.",

        "Keep going. You are closer than you think. 🌸"

    ],


    confidence: [

        "You are capable of more than you give yourself credit for. 💜",

        "You don't need permission to believe in yourself.",

        "Your voice matters. Your ideas matter. You matter.",

        "Confidence grows every time you choose to keep going.",

        "You are enough exactly as you are."

    ],


    study: [

        "Don't compare your beginning with someone else's middle. 📚",

        "Every page you study is a step closer to your goal.",

        "You don't have to study everything today. Just start.",

        "Your effort today creates opportunities for tomorrow.",

        "Believe in yourself and keep learning. 💜"

    ],


    life: [

        "Life does not have to be perfect to be beautiful. 🌿",

        "Sometimes the smallest moments become the most meaningful.",

        "You are allowed to change your path.",

        "Your story is still being written.",

        "There is still so much life waiting for you. 🌸"

    ]

};


/*
   Get all quotes from every category.
*/

function getAllQuotes() {

    let allQuotes = [];


    Object.keys(mindEaseQuotes).forEach(function (category) {

        allQuotes =
            allQuotes.concat(
                mindEaseQuotes[category]
            );

    });


    return allQuotes;

}


/*
   Current selected category.
*/

let currentQuoteCategory = "all";


/*
   Show a quote category.
*/

function showCategory(category, button) {

    currentQuoteCategory = category;


    /* Remove active class from all buttons */

    document
        .querySelectorAll(".category-btn")
        .forEach(function (btn) {

            btn.classList.remove("active");

        });


    /* Add active class to clicked button */

    if (button) {

        button.classList.add("active");

    }


    /*
       Display a new quote from the selected category.
    */

    displayRandomQuote();

}


/*
   Display random quote.
*/

function displayRandomQuote() {

    const quoteText =
        document.getElementById("quoteText");


    if (!quoteText) {
        return;
    }


    let quotes;


    if (currentQuoteCategory === "all") {

        quotes = getAllQuotes();

    }

    else {

        quotes =
            mindEaseQuotes[
                currentQuoteCategory
            ];

    }


    if (!quotes || quotes.length === 0) {

        return;

    }


    const randomIndex =
        Math.floor(
            Math.random() * quotes.length
        );


    const selectedQuote =
        quotes[randomIndex];


    /*
       Small fade effect.
    */

    quoteText.style.opacity = "0";


    setTimeout(function () {

        quoteText.textContent =
            selectedQuote;

        quoteText.style.opacity = "1";

    }, 150);

}


/*
   New Quote button.
*/

function newQuote() {

    displayRandomQuote();

}


/*
   Optional: save currently displayed quote.
*/

function favoriteCurrentQuote() {

    const quoteText =
        document.getElementById("quoteText");


    if (!quoteText) {
        return;
    }


    const quote =
        quoteText.textContent.trim();


    saveFavoriteQuote(quote);

}

/* =========================================================
   11. NEED TO TALK / CHATBOT
   ========================================================= */

let currentTopic = "";

let conversationCount = 0;


/* =========================================================
   SEND MESSAGE
   ========================================================= */

function sendMessage() {

    const input =
        document.getElementById("chatInput");


    if (!input) {
        return;
    }


    const message =
        input.value.trim();


    if (message === "") {
        return;
    }


    addUserMessage(message);


    input.value = "";


    conversationCount++;


    showTyping();


    setTimeout(function () {

        removeTyping();


        const reply =
            generateResponse(message);


        addBotMessage(reply);

    }, 700);

}


/* =========================================================
   QUICK MESSAGE
   ========================================================= */

function sendQuickMessage(message) {

    if (!message) {
        return;
    }


    addUserMessage(message);


    conversationCount++;


    showTyping();


    setTimeout(function () {

        removeTyping();


        const reply =
            generateResponse(message);


        addBotMessage(reply);

    }, 700);

}


/* =========================================================
   ADD USER MESSAGE
   ========================================================= */

function addUserMessage(message) {

    const chat =
        document.getElementById("chatMessages");


    if (!chat) {
        return;
    }


    const messageDiv =
        document.createElement("div");


    messageDiv.className =
        "message user-message";


    messageDiv.innerHTML = `

        <div class="message-bubble">

            <p>
                ${escapeHTML(message)}
            </p>

        </div>

    `;


    chat.appendChild(messageDiv);


    scrollChat();

}


/* =========================================================
   ADD BOT MESSAGE
   ========================================================= */

function addBotMessage(message) {

    const chat =
        document.getElementById("chatMessages");


    if (!chat) {
        return;
    }


    const messageDiv =
        document.createElement("div");


    messageDiv.className =
        "message bot-message";


    messageDiv.innerHTML = `

        <div class="message-avatar">
            🌸
        </div>

        <div class="message-bubble">

            ${message}

        </div>

    `;


    chat.appendChild(messageDiv);


    scrollChat();

}


/* =========================================================
   CHATBOT RESPONSE SYSTEM
   ========================================================= */

function generateResponse(message) {

    const text =
        message.toLowerCase().trim();


    /* =====================================================
       SAFETY
       ===================================================== */

    if (

        text.includes("suicide") ||

        text.includes("kill myself") ||

        text.includes("end my life") ||

        text.includes("hurt myself") ||

        text.includes("harm myself") ||

        text.includes("don't want to live") ||

        text.includes("do not want to live") ||

        text.includes("want to die") ||

        text.includes("wish i was dead")

    ) {

        currentTopic = "safety";


        return `

            <p>
                I'm really sorry that you're going
                through something this painful. 💜
            </p>

            <p>
                You deserve support from a real person
                who can be with you through this.
            </p>

            <p>
                Please reach out to someone you trust
                right now, such as a family member,
                friend, teacher or counsellor.
            </p>

            <p>
                If you feel you may be in immediate
                danger, please contact your local
                emergency services or go to the
                nearest emergency department.
            </p>

            <p>
                You don't have to handle this alone. 🌸
            </p>

        `;

    }


    /* =====================================================
       GREETING
       ===================================================== */

    if (

        text === "hi" ||

        text === "hello" ||

        text === "hey" ||

        text === "hii" ||

        text === "hiii" ||

        text.includes("good morning") ||

        text.includes("good evening")

    ) {

        currentTopic = "greeting";


        return `

            <p>
                Hey! 🌸 I'm glad you're here.
            </p>

            <p>
                You can talk to me about your day,
                studies, relationships, worries,
                stress or anything else on your mind.
            </p>

            <p>
                How are you feeling right now?
            </p>

        `;

    }


    /* =====================================================
       FEELING SAD / LOW
       ===================================================== */

    if (

        text.includes("sad") ||

        text.includes("unhappy") ||

        text.includes("cry") ||

        text.includes("crying") ||

        text.includes("tears") ||

        text.includes("low") ||

        text.includes("upset") ||

        text.includes("miserable") ||

        text.includes("down") ||

        text.includes("bad day") ||

        text.includes("feel terrible")

    ) {

        currentTopic = "sad";


        return `

            <p>
                I'm sorry you're having such a difficult
                moment. 💜
            </p>

            <p>
                You don't have to pretend that everything
                is okay here.
            </p>

            <p>
                Sometimes simply putting your feelings
                into words can make them feel a little
                lighter.
            </p>

            <p>
                Do you know what made you feel this way,
                or has it been building up for a while?
            </p>

        `;

    }


    /* =====================================================
       BREAKUP
       ===================================================== */

    if (

        text.includes("breakup") ||

        text.includes("break up") ||

        text.includes("broke up") ||

        text.includes("ex") ||

        text.includes("heartbroken") ||

        text.includes("heart break") ||

        text.includes("relationship ended")

    ) {

        currentTopic = "breakup";


        return `

            <p>
                I'm really sorry. Breakups can hurt
                deeply, especially when you cared a lot
                about the person. 💔
            </p>

            <p>
                It's completely okay if you're not
                "over it" yet. Healing doesn't happen
                on a fixed schedule.
            </p>

            <p>
                Do you want to tell me what happened?
                I'm listening. 💜
            </p>

        `;

    }


    /* =====================================================
       LONELINESS
       ===================================================== */

    if (

        text.includes("lonely") ||

        text.includes("alone") ||

        text.includes("nobody") ||

        text.includes("no one") ||

        text.includes("no friends") ||

        text.includes("isolated") ||

        text.includes("left out") ||

        text.includes("ignored")

    ) {

        currentTopic = "lonely";


        return `

            <p>
                Feeling alone can be really difficult. 🥺💜
            </p>

            <p>
                Sometimes loneliness isn't about being
                physically alone. It can also happen when
                you feel like nobody understands you.
            </p>

            <p>
                Is there someone you normally feel
                comfortable talking to?
            </p>

            <p>
                It could be a friend, family member,
                classmate or teacher.
            </p>

        `;

    }


    /* =====================================================
       ANXIETY / OVERTHINKING
       ===================================================== */

    if (

        text.includes("anxious") ||

        text.includes("anxiety") ||

        text.includes("nervous") ||

        text.includes("worried") ||

        text.includes("worry") ||

        text.includes("overthinking") ||

        text.includes("overthink") ||

        text.includes("panic") ||

        text.includes("scared") ||

        text.includes("fear") ||

        text.includes("restless")

    ) {

        currentTopic = "anxiety";


        return `

            <p>
                It sounds like your mind has been
                carrying a lot lately. 🌿
            </p>

            <p>
                Try taking one slow breath.
                You don't have to solve everything
                at this exact moment.
            </p>

            <p>
                Focus only on what is happening
                right now.
            </p>

            <p>
                What thought keeps coming back
                the most?
            </p>

        `;

    }


    /* =====================================================
       STRESS
       ===================================================== */

    if (

        text.includes("stress") ||

        text.includes("stressed") ||

        text.includes("pressure") ||

        text.includes("overwhelmed") ||

        text.includes("too much") ||

        text.includes("burnout") ||

        text.includes("burnt out") ||

        text.includes("can't handle")

    ) {

        currentTopic = "stress";


        return `

            <p>
                That sounds like a lot to carry. 💜
            </p>

            <p>
                When everything feels overwhelming,
                try not to solve everything at once.
            </p>

            <p>
                Take one slow breath and choose just
                one small thing you can deal with first.
            </p>

            <p>
                What's causing most of the stress
                right now?
            </p>

        `;

    }


    /* =====================================================
       STUDIES / COLLEGE / CAREER
       ===================================================== */

    if (

        text.includes("exam") ||

        text.includes("exams") ||

        text.includes("study") ||

        text.includes("studies") ||

        text.includes("college") ||

        text.includes("assignment") ||

        text.includes("project") ||

        text.includes("placement") ||

        text.includes("career") ||

        text.includes("marks") ||

        text.includes("result") ||

        text.includes("grades") ||

        text.includes("grade") ||

        text.includes("interview")

    ) {

        currentTopic = "study";


        return `

            <p>
                Academic pressure can definitely feel
                overwhelming. 📚💜
            </p>

            <p>
                Let's break it down instead of trying
                to solve everything at once.
            </p>

            <p>
                What is bothering you most?
            </p>

            <p>
                • The amount of work<br>
                • Fear of the result<br>
                • Lack of preparation<br>
                • Pressure from others<br>
                • Career or placement worries
            </p>

        `;

    }


    /* =====================================================
       ANGER
       ===================================================== */

    if (

        text.includes("angry") ||

        text.includes("anger") ||

        text.includes("mad") ||

        text.includes("frustrated") ||

        text.includes("annoyed") ||

        text.includes("irritated") ||

        text.includes("hate")

    ) {

        currentTopic = "anger";


        return `

            <p>
                It sounds like something has really
                frustrated you. 😣
            </p>

            <p>
                It's okay to feel angry. What matters
                is giving yourself some space before
                reacting.
            </p>

            <p>
                What happened?
            </p>

        `;

    }


    /* =====================================================
       FRIENDS / RELATIONSHIPS
       ===================================================== */

    if (

        text.includes("friend") ||

        text.includes("friendship") ||

        text.includes("relationship") ||

        text.includes("fight") ||

        text.includes("argument") ||

        text.includes("ignored me") ||

        text.includes("betrayed")

    ) {

        currentTopic = "relationship";


        return `

            <p>
                Problems with people we care about
                can hurt a lot. 💜
            </p>

            <p>
                Sometimes we don't even know whether
                to talk to them, give them space,
                or simply let things go.
            </p>

            <p>
                You can tell me what happened.
            </p>

            <p>
                I'm listening. 🌸
            </p>

        `;

    }


    /* =====================================================
       SLEEP / TIRED
       ===================================================== */

    if (

        text.includes("tired") ||

        text.includes("exhausted") ||

        text.includes("sleepy") ||

        text.includes("can't sleep") ||

        text.includes("cannot sleep") ||

        text.includes("insomnia") ||

        text.includes("sleep") ||

        text.includes("no sleep")

    ) {

        currentTopic = "sleep";


        return `

            <p>
                It sounds like you may need some rest. 🌙
            </p>

            <p>
                When we're exhausted, even small
                problems can feel much bigger.
            </p>

            <p>
                If you can, give yourself a little
                quiet time away from screens and
                pressure.
            </p>

            <p>
                Have you been getting enough rest lately?
            </p>

        `;

    }


    /* =====================================================
       HAPPY / POSITIVE
       ===================================================== */

    if (

        text.includes("happy") ||

        text.includes("good") ||

        text.includes("great") ||

        text.includes("amazing") ||

        text.includes("excited") ||

        text.includes("wonderful") ||

        text.includes("better") ||

        text.includes("feeling good")

    ) {

        currentTopic = "happy";


        return `

            <p>
                I'm really happy to hear that! 🌸💜
            </p>

            <p>
                It's nice to have moments that feel
                a little lighter.
            </p>

            <p>
                What made your day better?
            </p>

        `;

    }


    /* =====================================================
       MOTIVATION / FOCUS
       ===================================================== */

    if (

        text.includes("motivation") ||

        text.includes("motivated") ||

        text.includes("lazy") ||

        text.includes("unmotivated") ||

        text.includes("can't focus") ||

        text.includes("cannot focus") ||

        text.includes("procrastinating") ||

        text.includes("procrastinate")

    ) {

        currentTopic = "motivation";


        return `

            <p>
                You don't always need motivation before
                starting something. 🌱
            </p>

            <p>
                Sometimes motivation comes after taking
                the first small step.
            </p>

            <p>
                Try choosing one tiny task and give it
                just five minutes.
            </p>

            <p>
                What are you trying to get done?
            </p>

        `;

    }


    /* =====================================================
       CONFIDENCE / SELF WORTH
       ===================================================== */

    if (

        text.includes("confidence") ||

        text.includes("not good enough") ||

        text.includes("failure") ||

        text.includes("fail") ||

        text.includes("worthless") ||

        text.includes("insecure") ||

        text.includes("i'm not enough") ||

        text.includes("i am not enough") ||

        text.includes("hate myself")

    ) {

        currentTopic = "confidence";


        return `

            <p>
                Feeling unsure about yourself doesn't
                mean you aren't capable. 💜
            </p>

            <p>
                Your worth isn't determined by one
                mistake, one result, or someone else's
                opinion.
            </p>

            <p>
                Can you think of one thing you've
                handled successfully, even if it seemed
                small?
            </p>

        `;

    }


    /* =====================================================
       FOLLOW-UP RESPONSES
       ===================================================== */

    if (currentTopic === "breakup") {

        return `

            <p>
                I understand. 💔
            </p>

            <p>
                You don't have to rush yourself into
                feeling okay.
            </p>

            <p>
                Sometimes healing starts with simply
                allowing yourself to feel what you feel.
            </p>

            <p>
                What part of the breakup hurts the most?
            </p>

        `;

    }


    if (currentTopic === "sad") {

        return `

            <p>
                Take your time. 💜
            </p>

            <p>
                You don't need to explain everything
                perfectly.
            </p>

            <p>
                I'm here to listen without judging you.
            </p>

            <p>
                What has been weighing on you the most?
            </p>

        `;

    }


    if (currentTopic === "stress") {

        return `

            <p>
                I hear you. 💜
            </p>

            <p>
                Let's make things a little smaller.
            </p>

            <p>
                If you could remove just one source
                of pressure right now, what would it be?
            </p>

        `;

    }


    if (currentTopic === "anxiety") {

        return `

            <p>
                I hear you. 🌿
            </p>

            <p>
                Try bringing your attention back to
                something you can control right now.
            </p>

            <p>
                What thought is bothering you the most?
            </p>

        `;

    }


    if (currentTopic === "lonely") {

        return `

            <p>
                I'm listening. 🥺💜
            </p>

            <p>
                You don't have to make yourself sound
                okay for me.
            </p>

            <p>
                What do you wish someone would understand
                about how you're feeling?
            </p>

        `;

    }


    /* =====================================================
       DEFAULT RESPONSES
       ===================================================== */

    const responses = [

        `
            <p>
                Thank you for sharing that with me. 💜
            </p>

            <p>
                I'm listening.
            </p>

            <p>
                Would you like to tell me a little more?
            </p>
        `,


        `
            <p>
                I hear you. 🌸
            </p>

            <p>
                You don't need to explain everything
                perfectly.
            </p>

            <p>
                Tell me what's on your mind.
            </p>
        `,


        `
            <p>
                I'm here with you. 🌿
            </p>

            <p>
                What part of the situation is bothering
                you the most?
            </p>
        `,


        `
            <p>
                That sounds important to you. 💜
            </p>

            <p>
                Take your time.
            </p>

            <p>
                I'm listening.
            </p>
        `

    ];


    return responses[
        conversationCount % responses.length
    ];

}


/* =========================================================
   TYPING INDICATOR
   ========================================================= */

function showTyping() {

    const chat =
        document.getElementById("chatMessages");


    if (!chat) {
        return;
    }


    /* Prevent duplicate typing indicators */

    if (
        document.getElementById("typingIndicator")
    ) {

        return;

    }


    const typing =
        document.createElement("div");


    typing.id =
        "typingIndicator";


    typing.className =
        "message bot-message";


    typing.innerHTML = `

        <div class="message-avatar">
            🌸
        </div>

        <div class="typing-bubble">

            <span></span>
            <span></span>
            <span></span>

        </div>

    `;


    chat.appendChild(typing);


    scrollChat();

}


/* =========================================================
   REMOVE TYPING INDICATOR
   ========================================================= */

function removeTyping() {

    const typing =
        document.getElementById(
            "typingIndicator"
        );


    if (typing) {

        typing.remove();

    }

}


/* =========================================================
   SCROLL CHAT
   ========================================================= */

function scrollChat() {

    const chat =
        document.getElementById("chatMessages");


    if (chat) {

        chat.scrollTop =
            chat.scrollHeight;

    }

}


/* =========================================================
   CHAT INPUT - ENTER KEY
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const input =
            document.getElementById("chatInput");


        if (input) {

            input.addEventListener(
                "keydown",
                function (event) {

                    if (event.key === "Enter") {

                        event.preventDefault();

                        sendMessage();

                    }

                }
            );

        }

    }
);


/* =========================================================
   12. FAVORITE QUOTES
   ========================================================= */

function saveFavoriteQuote(quote) {

    if (!quote) {
        return;
    }


    const favorites =
        JSON.parse(
            localStorage.getItem(
                "mindEaseFavoriteQuotes"
            ) || "[]"
        );


    if (!favorites.includes(quote)) {

        favorites.push(quote);


        localStorage.setItem(
            "mindEaseFavoriteQuotes",
            JSON.stringify(favorites)
        );


        showNotification(
            "Quote saved to favorites 💜"
        );

    }

    else {

        showNotification(
            "This quote is already saved 🌸"
        );

    }

}


/* =========================================================
   13. DARK MODE
   ========================================================= */

function toggleDarkMode() {

    document.body.classList.toggle(
        "dark-mode"
    );


    const enabled =
        document.body.classList.contains(
            "dark-mode"
        );


    localStorage.setItem(
        "mindEaseDarkMode",
        enabled
    );

}


/* =========================================================
   14. SIMPLE NOTIFICATION
   ========================================================= */

function showNotification(message) {

    const notification =
        document.createElement("div");


    notification.className =
        "mindEase-notification";


    notification.textContent =
        message;


    document.body.appendChild(
        notification
    );


    setTimeout(function () {

        notification.classList.add(
            "show"
        );

    }, 10);


    setTimeout(function () {

        notification.classList.remove(
            "show"
        );


        setTimeout(function () {

            notification.remove();

        }, 300);

    }, 2500);

}


/* =========================================================
   15. HELPER - ESCAPE HTML
   ========================================================= */

function escapeHTML(text) {

    const div =
        document.createElement("div");


    div.textContent =
        text;


    return div.innerHTML;

}


/* =========================================================
   16. SMOOTH SCROLL
   ========================================================= */

function scrollToSection(id) {

    const section =
        document.getElementById(id);


    if (section) {

        section.scrollIntoView({

            behavior: "smooth",

            block: "start"

        });

    }

}
/* =========================================================
   18. EXERCISE MODAL
   ========================================================= */

function openExercise(exerciseId) {

    const modal =
        document.getElementById("exerciseModal");

    if (!modal) {
        return;
    }


    /* Hide all exercise content */

    const contents =
        document.querySelectorAll(".exercise-content");

    contents.forEach(function (content) {

        content.style.display = "none";

    });


    /* Find selected exercise */

    const selected =
        document.getElementById(exerciseId);

    if (!selected) {
        return;
    }


    /* Show selected exercise */

    selected.style.display = "block";


    /* Show modal */

    modal.style.display = "flex";

    modal.setAttribute("aria-hidden", "false");

}


/* =========================================================
   CLOSE EXERCISE
   ========================================================= */

function closeExercise() {

    const modal =
        document.getElementById("exerciseModal");

    if (!modal) {
        return;
    }


    modal.style.display = "none";

    modal.setAttribute("aria-hidden", "true");

}


/* =========================================================
   CLOSE WHEN CLICKING OUTSIDE
   ========================================================= */

document.addEventListener("click", function (event) {

    const modal =
        document.getElementById("exerciseModal");

    if (!modal) {
        return;
    }


    if (event.target === modal) {

        closeExercise();

    }

});


/* =========================================================
   ESCAPE KEY
   ========================================================= */

document.addEventListener("keydown", function (event) {

    if (event.key === "Escape") {

        closeExercise();

    }

});