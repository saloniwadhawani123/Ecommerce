# MindEase – Mental Health Support Chatbot

MindEase is a web-based mental wellness platform designed to provide users with a supportive space to express their feelings, practice mindfulness, and access helpful mental health resources.

## Features

*  **Need to Talk** – Supportive chatbot for stress, loneliness, sadness, breakups, and other emotional situations.
*  **Meditation** – Guided meditation with an interactive timer.
*  **Mind Exercises** – Simple activities for relaxation and mental wellness.
*  **Daily Journal** – Space to write and reflect on thoughts and feelings.
*  **Motivational Quotes** – Positive and encouraging quotes.
*  **Support** – Mental health resources and professional support information.

## Technologies Used

* **Frontend:** HTML, CSS, JavaScript
* **Backend:** Python, Flask
* **Database:** MySQL
* **Tools:** VS Code, Git, GitHub

## Objective

MindEase aims to promote mental wellness through technology by encouraging mindfulness, self-reflection, emotional expression, and access to support resources.

## Future Enhancements

* AI-powered chatbot
* Mood tracking and analytics
* Personalized recommendations
* User authentication
* Mobile application

> **"Take a moment. Breathe. You're not alone. "**

**Note:** MindEase is an educational project and does not replace professional mental health care.
